/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.github.keepoff07.hiyutosogame.TosoGameAPI;

public class TCPoint {

	static String pex = TosoCommands.pex;
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("set")) {
			if(args.length == 3 && sender instanceof Player) {
				Player p = (Player)sender;
				Location l = p.getLocation();
				if(set(sender, l, args[2])) return;
			}
		}
		senderror(sender, label);
		return;
	}
	@SuppressWarnings("deprecation")
	public static void doCommand_tp(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args.length == 2 & sender instanceof Player) {
			Player p = (Player)sender;
			if(tp(sender, p, args[1])) return;
		} else if(args.length == 3){
			Player p = Bukkit.getPlayerExact(args[2]);
			if(p == null) {
				sender.sendMessage(pex+"§c指定されたプレイヤーが見つかりません");
				return;
			} else {
				if(tp(sender, p, args[1])) return;
			}
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" p set <jail|rev|suc|gath>");
		sender.sendMessage("/"+label+" tp <jail|rev|suc|gath> [Player]");
	}
	private static boolean set(CommandSender sender, Location l, String arg){
		if(arg.equalsIgnoreCase("jail")){
			TosoGameAPI.setJailLocation(l);
			sender.sendMessage(pex+"§e牢屋§aを設定しました。");
			return true;
		}else if(arg.equalsIgnoreCase("rev")){
			TosoGameAPI.setRevivalLocation(l);
			sender.sendMessage(pex+"§e復活地点§aを設定しました。");
			return true;
		}else if(arg.equalsIgnoreCase("suc")){
			TosoGameAPI.setSuccessLocation(l);
			sender.sendMessage(pex+"§e逃走成功場所§aを設定しました。");
			return true;
		}else if(arg.equalsIgnoreCase("gath")){
			TosoGameAPI.setGatherLocation(l);
			sender.sendMessage(pex+"§eハンター集合場所§aを設定しました。");
			return true;
		} else return false;
	}

	private static boolean tp(CommandSender sender, Player p, String arg){
		if(arg.equalsIgnoreCase("jail")){
			Location l = TosoGameAPI.getJailLocation();
			if(l==null){
				sender.sendMessage(pex+"§c"+get(arg)+"が設定されていません。");
			} else {
				p.teleport(l);
				sender.sendMessage(pex+"§e"+p.getName()+"§aを§e"+get(arg)+"§aへテレポートさせました。");
			} return true;
		}else if(arg.equalsIgnoreCase("rev")){
			Location l = TosoGameAPI.getRevivalLocation();
			if(l==null){
				sender.sendMessage(pex+"§c"+get(arg)+"が設定されていません。");
			} else {
				p.teleport(l);
				sender.sendMessage(pex+"§e"+p.getName()+"§aを§e"+get(arg)+"§aへテレポートさせました。");
			} return true;
		}else if(arg.equalsIgnoreCase("suc")){
			Location l = TosoGameAPI.getSuccessLocation();
			if(l==null){
				sender.sendMessage(pex+"§c"+get(arg)+"が設定されていません。");
			} else {
				p.teleport(l);
				sender.sendMessage(pex+"§e"+p.getName()+"§aを§e"+get(arg)+"§aへテレポートさせました。");
			} return true;
		}else if(arg.equalsIgnoreCase("gath")){
			Location l = TosoGameAPI.getGatherLocation();
			if(l==null){
				sender.sendMessage(pex+"§c"+get(arg)+"が設定されていません。");
			} else {
				p.teleport(l);
				sender.sendMessage(pex+"§e"+p.getName()+"§aを§e"+get(arg)+"§aへテレポートさせました。");
			} return true;
		} else return false;
	}
	private static String get(String arg){
		if(arg.equalsIgnoreCase("jail")){
			return "牢屋";
		}else if(arg.equalsIgnoreCase("rev")){
			return "復活地点";
		}else if(arg.equalsIgnoreCase("suc")){
			return "逃走成功場所";
		}else if(arg.equalsIgnoreCase("gath")){
			return "ハンター集合場所";
		} else return null;
	}
}
