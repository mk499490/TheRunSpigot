/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.listener.TLHunterPlayer;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TCHunter {

	static String pex = TosoCommands.pex;
	@SuppressWarnings("deprecation")
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("add")) {
			if(args.length == 3) {
				Player p = Bukkit.getPlayerExact(args[2]);
				if(p == null) {
					sender.sendMessage(pex+"§c指定されたプレイヤーが見つかりません");
				} else {
					if(TosoGameAPI.isHunterPlayer(p)) {
						sender.sendMessage(pex+"§c指定されたプレイヤーは既にハンターです");
					} else {
						TosoGameAPI.addHunterPlayer(p);
						try {
							Bukkit.broadcastMessage(HIYU_TosoGame.message.getString("Hunter.Added").replace("%player", p.getName()));
						}catch(ConfigNotFoundException e){
							sender.sendMessage(pex+"§e"+p.getName()+"§bをハンターに追加しました。");
						}
					}
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("remove")) {
			if(args.length == 3) {
				Player p = Bukkit.getPlayerExact(args[2]);
				if(p == null) {
					sender.sendMessage(pex+"§c指定されたプレイヤーが見つかりません");
				} else {
					if(TosoGameAPI.isHunterPlayer(p)) {
						TosoGameAPI.removeHunterPlayer(p);
						sender.sendMessage(pex+"§e"+p.getName()+"§bをハンターから削除しました。");
					} else {
						sender.sendMessage(pex+"§c指定されたプレイヤーは既にハンターではありません。");
					}
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("clear")) {
			TosoGameAPI.clearTosoPlayer();
			sender.sendMessage(pex+"§aハンターの情報を初期化しました。");
			return;
		}
		else if(args[1].equalsIgnoreCase("random")) {
			Player p = TLHunterPlayer.HunterSupport();
			if(p == null){
				sender.sendMessage(pex+"§cハンターに追加できるプレイヤーが存在しません。");
			} else {
				TosoGameAPI.addHunterPlayer(p);
				try {
					Bukkit.broadcastMessage(HIYU_TosoGame.message.getString("Hunter.Added").replace("%player", p.getName()));
				}catch(ConfigNotFoundException e){
					sender.sendMessage(pex+"§e"+p.getName()+"§bをハンターに追加しました。");
				}
			}
			return;
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" h add <Player>");
		sender.sendMessage("/"+label+" h remove <Player>");
		sender.sendMessage("/"+label+" h clear");
		sender.sendMessage("/"+label+" h random");
	}
}
