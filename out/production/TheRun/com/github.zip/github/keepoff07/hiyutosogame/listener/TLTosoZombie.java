/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TLTosoZombie implements Listener{

	public static Map<String, Entity> dataEnt = new HashMap<String, Entity>();
	public static Map<String, BukkitTask> dataTask = new HashMap<String, BukkitTask>();
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onHunterCatch(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Zombie && isTosoZombie(defent)){
				final Zombie def = (Zombie)defent;
				if(attent instanceof Player){
					Player att = (Player)attent;
					if(TosoGameAPI.isHunterPlayer(att) & def.getCustomName() != null){
						e.setCancelled(true);
						String name = def.getCustomName();
						dataTask.remove(name);
						dataEnt.remove(name);
						Utility.sendAnnounce("HunterPlayer.Catch", att, name);
						TosoScoreBoard.jail.addPlayer(Bukkit.getOfflinePlayer(name));
						def.playEffect(EntityEffect.DEATH);
						Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
							@Override
							public void run() {
								def.remove();
							}
						}, 20);
					} else {
						e.setCancelled(true);
					}
				} else {
					e.setCancelled(true);
				}
			}
		}
	}
	@EventHandler
	public void onHunterTarget(EntityTargetLivingEntityEvent e) {
		Entity ent = e.getEntity();
		if(ent instanceof Zombie && isTosoZombie(ent)) {
			e.setCancelled(true);
		}
	}
	@EventHandler
	public void onPlayerLogout(PlayerQuitEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(!TosoTimer.onGame) return;
			if(TosoScoreBoard.isTosoPlayer(p, true)|TosoScoreBoard.isSuccessPlayer(p)){
				int i = 0;
				try{
					i = HIYU_TosoGame.config.getInt("TosoPlayer.AntiRelog") * 20;
				}catch(ConfigNotFoundException ex){}
				if(i > 0){
					String name = p.getName();
					Location l = p.getLocation();
					Zombie z = (Zombie)p.getWorld().spawnEntity(l, EntityType.ZOMBIE);
					EntityEquipment eu = z.getEquipment();
					eu.setArmorContents(new ItemStack[]{
							createItem_color(Material.LEATHER_BOOTS),
							createItem_color(Material.LEATHER_LEGGINGS),
							createItem_color(Material.LEATHER_CHESTPLATE),
							createItem_color(Material.LEATHER_HELMET)
					});
					z.setCustomName(name);
					z.setCustomNameVisible(true);
					z.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, Integer.MAX_VALUE, 100, true));
					z.setMetadata("TosoZombie", new FixedMetadataValue(HIYU_TosoGame.plugin, true));
					BukkitTask task = new NPCRunnable(z).runTaskLater(HIYU_TosoGame.plugin, i);
					dataTask.put(name, task);
					dataEnt.put(name, z);
				}
			}
		}
	}
	private ItemStack createItem_color(Material m){
		ItemStack item = new ItemStack(m);
		LeatherArmorMeta mt = (LeatherArmorMeta)item.getItemMeta();
		mt.setColor(Color.PURPLE);
		item.setItemMeta(mt);
		return item;
	}
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e){
		if(HIYU_TosoGame.read){
			final Player p = e.getPlayer();
			if(TosoGameAPI.isCaughtPlayer(p)){
				Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
					@Override
					public void run() {
						Location l = TosoGameAPI.getJailLocation();
						if(l != null) p.teleport(l);
						p.getInventory().clear();
						TosoGameAPI.removeArmor(p);
						p.setFoodLevel(20);
						p.setWalkSpeed(0.2f);
						for(PotionEffect t : p.getActivePotionEffects()){
							p.removePotionEffect(t.getType());
						}
					}
				}, 2);
			}
			else if(TosoGameAPI.isTosoPlayer(p)){
				String name = p.getName();
				if(dataEnt.containsKey(name)){
					dataEnt.get(name).remove();
					dataEnt.remove(name);
				}
				if(dataTask.containsKey(name)){
					dataTask.get(name).cancel();
					dataTask.remove(name);
				}
			}
		}
	}
	public static boolean isTosoZombie(Entity zon) {
		return zon.hasMetadata("TosoZombie");
	}

	public static class NPCRunnable extends BukkitRunnable {
		Entity ent;
		public NPCRunnable(Entity e){
			ent = e;
		}
		@Override
		public void run() {
			ent.remove();
		}
	}
}
