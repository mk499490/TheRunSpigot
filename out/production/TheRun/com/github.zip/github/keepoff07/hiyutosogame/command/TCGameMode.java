/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class TCGameMode {
	
	public static List<String> hides = new ArrayList<String>();
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) return;
		try{
			if(sender instanceof Player){
				Player p = (Player)sender;
				int i = Integer.parseInt(args[1]);
				if(i == 0){
					remove(p);
					p.setGameMode(GameMode.SURVIVAL);
				}else if(i == 1){
					remove(p);
					p.setGameMode(GameMode.CREATIVE);
				}else if(i == 2){
					remove(p);
					p.setGameMode(GameMode.ADVENTURE);
				}else if(i == 3){
					add(p);
				}
			}
		}catch(NumberFormatException e){
			sender.sendMessage(ChatColor.RED+e.getMessage());
		}
		return;
	}
	private static void remove(Player p){
		String name = p.getName();
		if(hides.contains(name)){
			hides.remove(name);
		}
		if(p.hasPotionEffect(PotionEffectType.INVISIBILITY))
			p.removePotionEffect(PotionEffectType.INVISIBILITY);
		if(p.hasPotionEffect(PotionEffectType.NIGHT_VISION))
			p.removePotionEffect(PotionEffectType.NIGHT_VISION);
		for (Player online : Bukkit.getOnlinePlayers()) {
			online.showPlayer(p);
		}
	}
	private static void add(Player p){
		String name = p.getName();
		if(!hides.contains(name)){
			hides.add(name);
		}
		p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY,Integer.MAX_VALUE, 0, true),true);
		p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,Integer.MAX_VALUE, 0, true),true);
		for (Player online : Bukkit.getOnlinePlayers()) {
			online.hidePlayer(p);
		}
		p.setGameMode(GameMode.CREATIVE);
		p.getInventory().addItem(new ItemStack(Material.COMPASS));
	}
}
