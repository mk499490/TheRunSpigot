/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame;

import java.io.File;

import net.milkbowl.vault.economy.Economy;

import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import com.github.keepoff07.hiyutosogame.command.TosoCommands;
import com.github.keepoff07.hiyutosogame.listener.TLHunterPlayer;
import com.github.keepoff07.hiyutosogame.listener.TLHunterZombie;
import com.github.keepoff07.hiyutosogame.listener.TLMission;
import com.github.keepoff07.hiyutosogame.listener.TLPlayerControl;
import com.github.keepoff07.hiyutosogame.listener.TLTosoPlayer;
import com.github.keepoff07.hiyutosogame.listener.TLTosoZombie;
import com.github.keepoff07.hiyutosogame.timer.SidebarUpdateRunnale;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;

public class HIYU_TosoGame extends JavaPlugin{

	public static HIYU_TosoGame plugin;
	public static Economy economy;
	public void onEnable(){
		plugin = this;

		RegisteredServiceProvider<Economy> economyProvider = getServer().getServicesManager().getRegistration(Economy.class);
		if(economyProvider != null){
			economy = ((Economy)economyProvider.getProvider());
		}

		load();
		PluginManager pm = getServer().getPluginManager();
		pm.registerEvents(new TLPlayerControl(), this);
		pm.registerEvents(new TLTosoPlayer(), this);
		pm.registerEvents(new TLTosoZombie(), this);
		pm.registerEvents(new TLHunterPlayer(), this);
		pm.registerEvents(new TLHunterZombie(), this);
		pm.registerEvents(new TLMission(), this);
		getCommand("toso").setExecutor(new TosoCommands());
		if(!getDescription().getAuthors().contains("keepoff07")){
			read = false;
			throw new StringIndexOutOfBoundsException();
		}
		TosoScoreBoard.reset();
		new SidebarUpdateRunnale().runTaskTimer(this, 0, 200);
	}
	public void onDisable(){
		TLMission.reset();
	}

	public static boolean read = true;
	public static Config config = null;
	public static Config point = null;
	public static Config box = null;
	public static Config message = null;
	public static Config teams = null;
	public static Config sidebar = null;
	public static Config book = null;
	public static Config mission = null;
	public static Config items = null;

	public static void load() {
		String folderPath = plugin.getDataFolder().getAbsolutePath();
		config = load(folderPath, "config.yml");
		point = load(folderPath, "tppoint.yml");
		box = load(folderPath, "opboxs.yml");
		message = load(folderPath, "message.yml");
		teams = load(folderPath, "teams.yml");
		sidebar = load(folderPath, "sidebar.yml");
		book = load(folderPath, "books.yml");
		mission = load(folderPath, "mission.yml");
		items = load(folderPath, "items.yml");
		if(config == null | point == null | box == null) {
			plugin.getLogger().warning("ファイルの読み込み、生成に失敗しました。作者に報告してください。");
			read = false;
		}
	}
	private static Config load(String folderPath, String path) {
		File file = new File(folderPath, path);
		if(!file.exists()) {
			plugin.getLogger().info(path+"を作成します...");
			Utility.output(plugin, path);
		}
		if(file.exists()) {
			Config config = new Config(file);
			plugin.getLogger().info(path+"を読み込みました。");
			return config;
		} else {
			plugin.getLogger().warning(path+"の読み込みに失敗しました。");
			return null;
		}
	}
}
