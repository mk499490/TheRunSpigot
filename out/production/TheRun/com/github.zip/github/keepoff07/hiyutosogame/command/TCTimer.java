/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.command.CommandSender;

import com.github.keepoff07.hiyutosogame.timer.TosoTimer;

public class TCTimer {

	static String pex = TosoCommands.pex;
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("set")){
			if(args.length == 3) {
				try{
					int i = Integer.parseInt(args[2]);
					TosoTimer.gametime = i;
					sender.sendMessage(pex+"§aゲーム時間を "+i+"秒に設定しました。");
				}catch(NumberFormatException e){
					sender.sendMessage(pex+"§c入力した値に問題があります");
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("countdown")){
			if(args.length == 3) {
				try{
					int i = Integer.parseInt(args[2]);
					TosoTimer.countdown = i;
					sender.sendMessage(pex+"§aカウントダウンを "+i+"秒に設定しました。");
				}catch(NumberFormatException e){
					sender.sendMessage(pex+"§c入力した値に問題があります");
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("end")){
			if(TosoTimer.endTimer()){
				sender.sendMessage(pex+"§7タイマーを停止しました。");
			} else {
				sender.sendMessage(pex+"§cタイマーが動作していません。");
			}
			return;
		}
		else if(args[1].equalsIgnoreCase("debug")){
			TosoTimer.startTimer();
			return;
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" timer set <秒>");
		sender.sendMessage("/"+label+" timer countdown <秒>");
		sender.sendMessage("/"+label+" timer end");
	}
}
