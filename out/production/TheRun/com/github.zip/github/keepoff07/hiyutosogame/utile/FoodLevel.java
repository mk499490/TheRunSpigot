/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.utile;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class FoodLevel {

	private static Map<UUID, BukkitTask> map = new HashMap<UUID, BukkitTask>();
	public static void FoodReduce(Player player) {
		if(HIYU_TosoGame.read){
			UUID uuid = player.getUniqueId();
			if(a("HunterPlayer") && TosoGameAPI.isHunterPlayer(player)) {
				if(map.containsKey(uuid)) map.get(uuid).cancel();
				BukkitTask task = new Down(player).runTaskTimer(HIYU_TosoGame.plugin, b("HunterPlayer"), b("HunterPlayer"));
				map.put(uuid, task);
			} else if(a("TosoPlayer") && TosoGameAPI.isTosoPlayer(player) & !TosoGameAPI.isCaughtPlayer(player)) {
				if(map.containsKey(uuid)) map.get(uuid).cancel();
				BukkitTask task = new Down(player).runTaskTimer(HIYU_TosoGame.plugin, b("TosoPlayer"), b("TosoPlayer"));
				map.put(uuid, task);
			} else {
				player.setFoodLevel(20);
			}
		}
	}
	public static void FoodHeal(Player player) {
		if(HIYU_TosoGame.read){
			UUID uuid = player.getUniqueId();
			if(a("HunterPlayer") && TosoGameAPI.isHunterPlayer(player)) {
				if(map.containsKey(uuid)) map.get(uuid).cancel();
				if(player.getFoodLevel() <= 6) {
					Utility.sendAnnounce("HunterPlayer.Fatigue", player);
					PotionEffect effect = TosoGameAPI.getPotionEffect(PotionEffectType.HUNGER, HIYU_TosoGame.config, "HunterPlayer.Fatigue");
					player.addPotionEffect(effect);
				}
				BukkitTask task = new Up(player).runTaskTimer(HIYU_TosoGame.plugin, c("HunterPlayer"), c("HunterPlayer"));
				map.put(uuid, task);
			} else if(a("TosoPlayer") && TosoGameAPI.isTosoPlayer(player) & !TosoGameAPI.isCaughtPlayer(player)) {
				if(map.containsKey(uuid)) map.get(uuid).cancel();
				if(player.getFoodLevel() <= 6) {
					Utility.sendAnnounce("TosoPlayer.Fatigue", player);
					PotionEffect effect = TosoGameAPI.getPotionEffect(PotionEffectType.HUNGER, HIYU_TosoGame.config, "TosoPlayer.Fatigue");
					player.addPotionEffect(effect);
				}
				BukkitTask task = new Up(player).runTaskTimer(HIYU_TosoGame.plugin, c("TosoPlayer"), c("TosoPlayer"));
				map.put(uuid, task);
			} else {
				player.setFoodLevel(20);
			}
		}
	}
	public static class Down extends BukkitRunnable {
		Player player;
		public Down(Player p) {
			this.player = p;
		}
		@Override
		public void run() {
			if(player.isSprinting()) {
				if(!e(player)) {
					player.setFoodLevel(player.getFoodLevel() - 1);
				}
			} else {
				cancel();
			}
		}
	}
	public static class Up extends BukkitRunnable {
		Player player;
		public Up(Player p) {
			this.player = p;
		}
		@Override
		public void run() {
			if(!player.isSprinting()) {
				int f = player.getFoodLevel();
				if(f < 20) player.setFoodLevel(f + 1);
				else cancel();
			} else {
				cancel();
			}
		}
	}
	private static boolean a(String path){
		try {
			return HIYU_TosoGame.config.getBoolean(path+".ReduceFoodLevel");
		}catch(ConfigNotFoundException e){
			return true;
		}
	}
	private static int b(String path){
		try {
			return HIYU_TosoGame.config.getInt(path+".FoodReduceSpeed");
		}catch(ConfigNotFoundException e){
			return 4;
		}
	}
	private static int c(String path){
		try {
			return HIYU_TosoGame.config.getInt(path+".FoodHealSpeed");
		}catch(ConfigNotFoundException e){
			return 2;
		}
	}
	private static boolean d(String path){
		try {
			return HIYU_TosoGame.config.getBoolean(path+".DisableReduce_UseFeather");
		}catch(ConfigNotFoundException e){
			return true;
		}
	}
	public static boolean e(Player player){
		return d("TosoPlayer") && player.hasPotionEffect(PotionEffectType.SPEED);
	}
}
