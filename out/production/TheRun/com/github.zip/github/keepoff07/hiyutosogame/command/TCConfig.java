/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.command.CommandSender;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TCConfig {

	static String pex = TosoCommands.pex;
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("edit")) {
			if(args.length >= 5) {
				Config config = getConfig(args[2]);
				if(config == null) {
					sender.sendMessage(pex+"��c"+args[2]+"�͗L����FileName�ł͂���܂���");
					sender.sendMessage(pex+"��cFileName: config|books|items|message|mission|opboxs|sidebar|teams|tppoint");
					return;
				}
				String name = getConfigname(args[2]);
				String path = args[3];
				ObjectType type = ObjectType.get(args[4]);
				if(type == null) {
					sender.sendMessage(pex+"��c"+args[4]+"�͗L����ObjectType�ł͂���܂���");
					sender.sendMessage(pex+"��cObjerctType: String|Int|Double|Boolean");
					return;
				}
				try {
					String value = args[5];
					switch(type){
					case Boolean: {
						try {
							boolean o = config.getBoolean(path);
							boolean a = Boolean.parseBoolean(value);
							config.set(path, a);
							sender.sendMessage(pex+"��9"+path+" ��7("+name+")");
							sender.sendMessage(pex+"��9"+o+"��f -> ��c"+a);
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					case Double: {
						try {
							double o = config.getDouble(path);
							double a = Double.parseDouble(value);
							config.set(path, a);
							sender.sendMessage(pex+"��9"+path+" ��7("+name+")");
							sender.sendMessage(pex+"��9"+o+"��f -> ��c"+a);
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}catch(NumberFormatException e3){
							sender.sendMessage(pex+"��c"+value+"��"+type+"�ɂ���ɂ͕s�K�؂Ȓl�ł�");
						}
						break;
					}
					case Integer: {
						try {
							int o = config.getInt(path);
							int a = Integer.parseInt(value);
							config.set(path, a);
							sender.sendMessage(pex+"��9"+path+" ��7("+name+")");
							sender.sendMessage(pex+"��9"+o+"��f -> ��c"+a);
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}catch(NumberFormatException e3){
							sender.sendMessage(pex+"��c"+value+"��"+type+"�ɂ���ɂ͕s�K�؂Ȓl�ł�");
						}
						break;
					}
					case String: {
						try {
							String o = config.getString(path);
							String a = "";
							for(int i = 5; i < args.length; i++){
								a = " "+args[i];
							}
							a = a.substring(1).replace("&", "��");
							config.set(path, a);
							sender.sendMessage(pex+"��9"+path+" ��7("+name+")");
							sender.sendMessage(pex+"��9"+o);
							sender.sendMessage(pex+"��f-> ��c"+a);
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					}
				}catch(ArrayIndexOutOfBoundsException e1) {
					switch(type){
					case Boolean: {
						try {
							boolean o = config.getBoolean(path);
							sender.sendMessage(pex+"��9"+path+":��e"+o+" ��7("+name+")");
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					case Double: {
						try {
							double o = config.getDouble(path);
							sender.sendMessage(pex+"��9"+path+":��e"+o+" ��7("+name+")");
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					case Integer: {
						try {
							int o = config.getInt(path);
							sender.sendMessage(pex+"��9"+path+":��e"+o+" ��7("+name+")");
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					case String: {
						try {
							String o = config.getString(path);
							sender.sendMessage(pex+"��9"+path+":��e"+o+" ��7("+name+")");
						}catch(ConfigNotFoundException e2) {
							sender.sendMessage(pex+"��c"+path+"("+name+")�ɂ�"+type+"�����݂��܂���B");
						}
						break;
					}
					}
				}
				return;
			}
		}
		/*else if(args[1].equalsIgnoreCase("reload")) {
			if(args.length == 3) {
				Config config = getConfig(args[2]);
				if(config == null) {
					sender.sendMessage(pex+"��c"+args[2]+"�͗L����FileName�ł͂���܂���");
					sender.sendMessage(pex+"��cFileName: config|message|player|point|box");
					return;
				}
				config.reload();
				HIYU_TosoGame.load();
				sender.sendMessage(pex+"��a"+getConfigname(args[2])+" ���ēǂݍ��݂��܂����B");
				return;
			} else if(args.length == 2) {
				HIYU_TosoGame.load();
				sender.sendMessage(pex+"��a�ݒ�t�@�C�����ēǂݍ��݂��܂����B");
				return;
			}
		}*/
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" config edit <FileName> <Path> <ObjectType> [Value]");
		sender.sendMessage("/"+label+" reload");
	}
	public static void AllReload(CommandSender sender) {
		HIYU_TosoGame.config.reload();
		HIYU_TosoGame.message.reload();
		HIYU_TosoGame.point.reload();
		HIYU_TosoGame.box.reload();
		HIYU_TosoGame.sidebar.reload();
		HIYU_TosoGame.load();
		TCMission.loadMissionConfig();
		sender.sendMessage(pex+"��a�ݒ�t�@�C�����ēǂݍ��݂��܂����B");
		return;
	}

	public static enum ObjectType {
		String,
		Integer,
		Double,
		Boolean;

		public static ObjectType get(String arg){
			if(arg.equalsIgnoreCase("string")) return ObjectType.String;
			else if(arg.equalsIgnoreCase("int")) return ObjectType.Integer;
			else if(arg.equalsIgnoreCase("double")) return ObjectType.Double;
			else if(arg.equalsIgnoreCase("boolean")) return ObjectType.Boolean;
			else return null;
		}
	}
	private static Config getConfig(String arg){
		if(arg.equalsIgnoreCase("config")) return HIYU_TosoGame.config;
		else if(arg.equalsIgnoreCase("books")) return HIYU_TosoGame.book;
		else if(arg.equalsIgnoreCase("items")) return HIYU_TosoGame.items;
		else if(arg.equalsIgnoreCase("message")) return HIYU_TosoGame.message;
		else if(arg.equalsIgnoreCase("mission")) return HIYU_TosoGame.mission;
		else if(arg.equalsIgnoreCase("opboxs")) return HIYU_TosoGame.box;
		else if(arg.equalsIgnoreCase("sidebar")) return HIYU_TosoGame.sidebar;
		else if(arg.equalsIgnoreCase("teams")) return HIYU_TosoGame.teams;
		else if(arg.equalsIgnoreCase("tppoint")) return HIYU_TosoGame.point;
		else return null;
	}
	private static String getConfigname(String arg){
		return arg.toLowerCase()+".yml";
	}
}
