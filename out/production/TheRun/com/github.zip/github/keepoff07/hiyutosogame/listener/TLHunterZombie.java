/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import java.util.HashMap;
import java.util.Map;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TLHunterZombie implements Listener{

	@EventHandler
	public void onHunterCatch(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Player && attent instanceof Zombie){
				final Zombie att = (Zombie)attent;
				final Player def = (Player)defent;
				if(TosoTimer.onGame && TLMission.isHunterZombie(att) &&
						(TosoGameAPI.isTosoPlayer(def) & !TosoGameAPI.isCaughtPlayer(def))){
					if(def.hasPotionEffect(PotionEffectType.INVISIBILITY)){
						e.setCancelled(true);
						return;
					} else {
						e.setDamage(0d);
						TosoGameAPI.addCaughtPlayer(def);
						att.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 60, 100, true));
						breakTarget(def);
						Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable(){
							@Override
							public void run() {
								Location l = TosoGameAPI.getJailLocation();
								if(l != null) def.teleport(l);
								Utility.sendAnnounce("HunterPlayer.CatchByZombie", null, def);
								Utility.sendAnnounce("TosoPlayer.CatchByZombie", def);
							}
						}, 60l);
					}
				} else {
					e.setCancelled(true);
				}
			}
		}
	}
	@EventHandler
	public void onHunterDamage(EntityDamageByEntityEvent event){
		if(HIYU_TosoGame.read){
			Entity defent = event.getEntity();
			Entity attent = event.getDamager();
			if(attent instanceof Player && defent instanceof Zombie){
				final Zombie def = (Zombie)defent;
				//final Player att = (Player)attent;
				if(TLMission.isHunterZombie(def)) {
					event.setCancelled(true);
				}
			}
		}
	}
	@EventHandler
	public void onHunterTarget(EntityTargetLivingEntityEvent event) {
		Entity ent = event.getEntity();
		LivingEntity tag = event.getTarget();
		if(ent instanceof Zombie && TLMission.isHunterZombie(ent)) {
			if(TosoTimer.onGame) {
				if(tag instanceof Player) {
					Player def = (Player)tag;
					if(TosoGameAPI.isCaughtPlayer(def) || TosoGameAPI.isHunterPlayer(def)) {
						event.setCancelled(true);
					} else if(TosoGameAPI.isTosoPlayer(def)) {
						if(def.hasPotionEffect(PotionEffectType.INVISIBILITY))
							event.setCancelled(true);
						return;
					}
				} else event.setCancelled(true);
			} else event.setCancelled(true);
		}
	}
	public static void breakTarget(Player player) {
		for(Entity ent : player.getWorld().getEntities()) {
			if(TLMission.isHunterZombie(ent)) {
				Zombie zom = (Zombie)ent;
				if(zom.getTarget() != null && zom.getTarget().equals(player)) {
					zom.setTarget(null);
				}
			}
		}
	}
	@EventHandler
	public void onHunterDamageEgg(EntityDamageByEntityEvent event){
		if(HIYU_TosoGame.read){
			Entity defent = event.getEntity();
			Entity attent = event.getDamager();
			if(defent instanceof Zombie && attent instanceof Egg){
				Zombie def = (Zombie)defent;
				if(TosoTimer.onGame && TLMission.isHunterZombie(defent)){
					if(!def.hasPotionEffect(PotionEffectType.DAMAGE_RESISTANCE)){
						PotionEffect ef1 = TosoGameAPI.getPotionEffect(PotionEffectType.BLINDNESS,"ItemSetting");
						PotionEffect ef2 = TosoGameAPI.getPotionEffect(PotionEffectType.DAMAGE_RESISTANCE,"ItemSetting");
						def.setTarget(null);
						if(ef1 != null) def.addPotionEffect(ef1);
						if(ef2 != null) def.addPotionEffect(ef2);
						Utility.sendAnnounce("HunterPlayer.Hit_Blindness", null);
						ProjectileSource pro = ((Egg)attent).getShooter();
						if(pro instanceof Player){
							Utility.sendAnnounce("TosoPlayer.Hit_Blindness", (Player)pro);
						}
					}
					else event.setCancelled(true);
				} else {
					event.setCancelled(true);
				}
			}
		}
	}
	@EventHandler
	public void onHunterDamageSnowball(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Zombie && attent instanceof Snowball){
				Zombie def = (Zombie)defent;
				if(TosoTimer.onGame && TLMission.isHunterZombie(defent)){
					if(!isFenceStop(def)){
						ironfence(def);
						Utility.sendAnnounce("HunterPlayer.Hit_Snowball", null);
						ProjectileSource pro = ((Snowball)attent).getShooter();
						if(pro instanceof Player){
							Utility.sendAnnounce("TosoPlayer.Hit_Snowball", (Player)pro);
						}
					} else e.setCancelled(true);
				} else {
					e.setCancelled(true);
				}
			}
		}
	}
	boolean isFenceStop(Zombie zom){
		return zom.hasPotionEffect(PotionEffectType.FIRE_RESISTANCE);
	}
	void ironfence(Zombie zom){
		if(!isFenceStop(zom)){
			long time = 100;
			try{
				time = HIYU_TosoGame.items.getInt("SnowballCoolTime") * 20;
			}catch(ConfigNotFoundException e){}
			final int i = place(zom.getLocation());
			zom.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, (int)time, 0), true);
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable(){
				@Override
				public void run() {
					replace(i);
				}
			}, time);
		}
	}
	Map<Integer, Location[][][]> fence = new HashMap<Integer, Location[][][]>();
	int place(Location l){
		int i = 0;
		while(fence.containsKey(Integer.valueOf(i))){
			i++;
		}
		Location[][][] locs = new Location[3][3][3];
		World w = l.getWorld();
		int cx = 0;
		for(int x = l.getBlockX()-1; x < l.getBlockX()+2; x++){
			int cy = 0;
			for(int y = l.getBlockY()-1; y < l.getBlockY()+2; y++){
				int cz = 0;
				for(int z = l.getBlockZ()-1; z < l.getBlockZ()+2; z++){
					if(x == l.getBlockX() && z == l.getBlockZ()){
						locs[cx][cy][cz] = null;
						continue;
					}
					Location loc = new Location(w,x,y,z);
					Block b = loc.getBlock();
					if(b.getType().equals(Material.AIR)){
						b.setType(Material.IRON_FENCE);
						locs[cx][cy][cz] = loc;
					} else {
						locs[cx][cy][cz] = null;
					}
					cz++;
				}
				cy++;
			}
			cx++;
		}
		fence.put(Integer.valueOf(i), locs);
		return i;
	}
	void replace(int i){
		if(fence.containsKey(Integer.valueOf(i))){
			Location[][][] locs = fence.get(Integer.valueOf(i));
			for(int x = 0; x < 3; x++){
				for(int y = 0; y < 3; y++){
					for(int z = 0; z < 3; z++){
						Location loc = locs[x][y][z];
						if(loc != null){
							loc.getBlock().setType(Material.AIR);
						}
					}
				}
			}
		}
	}
}
