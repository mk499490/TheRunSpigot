/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.utile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;

public class Utility {

	public static void output(JavaPlugin plugin, String fileName){
		try{
			InputStream is = plugin.getResource(fileName);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			String content = "";
			String str;
			while((str = br.readLine()) != null){
				content = content + str + "\n";
			}
			br.close();
			is.close();
			
			String outputPathFull = plugin.getDataFolder().getAbsolutePath();
			File outputFolder = new File(outputPathFull);
			File outputFile = new File(outputPathFull, fileName);
			if(!outputFolder.exists()) outputFolder.mkdirs();
			if(!outputFile.exists()) outputFile.createNewFile();
			BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
			bw.write(content);
			bw.close();
		}catch(FileNotFoundException e){
			plugin.getLogger().warning("FileNotFoundException");
		}catch(IOException e){
			plugin.getLogger().warning("IOException");
		}
	}
	public static class Config {
		private File file;
		private YamlConfiguration config;
		
		
		public Config(File file, YamlConfiguration config) {
			this.file = file;
			this.config = config;
		}
		public Config(File file) {
			YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
			this.file = file;
			this.config = config;
		}
		
		public String getString(String path) throws ConfigNotFoundException {
			if(config.contains(path) && config.isString(path)) {
				return config.getString(path);
			} else {
				throw new ConfigNotFoundException();
			}
		}
		public boolean getBoolean(String path) throws ConfigNotFoundException {
			if(config.contains(path) && config.isBoolean(path)) {
				return config.getBoolean(path);
			} else {
				throw new ConfigNotFoundException();
			}
		}
		public int getInt(String path) throws ConfigNotFoundException {
			if(config.contains(path)) {
				if(config.isInt(path)) {
					return config.getInt(path);
				} else if(config.isString(path)) {
					try {
						return Integer.parseInt(config.getString(path));
					} catch(NumberFormatException e) {
						throw new ConfigNotFoundException();
					}
				} else if(config.isDouble(path)) {
					return (int)config.getDouble(path);
				}
			}
			throw new ConfigNotFoundException();
		}
		public double getDouble(String path) throws ConfigNotFoundException {
			if(config.contains(path)) {
				if(config.isDouble(path)) {
					return config.getDouble(path);
				} else if(config.isString(path)) {
					try {
						return Double.parseDouble(config.getString(path));
					} catch(NumberFormatException e) {
						throw new ConfigNotFoundException();
					}
				} else if(config.isInt(path)) {
					return (double)config.getInt(path);
				}
			}
			throw new ConfigNotFoundException();
		}
		public List<String> getStringList(String path) throws ConfigNotFoundException {
			if(config.contains(path) && config.isList(path)) {
				return config.getStringList(path);
			}
			throw new ConfigNotFoundException();
		}
		public String optString(String path, String def) {
			if(config.contains(path) && config.isString(path)) {
				return config.getString(path);
			} else {
				return def;
			}
		}
		public boolean optBoolean(String path, boolean def) {
			if(config.contains(path) && config.isBoolean(path)) {
				return config.getBoolean(path);
			} else {
				return def;
			}
		}
		public int optInt(String path, int def) {
			if(config.contains(path)) {
				if(config.isInt(path)) {
					return config.getInt(path);
				} else if(config.isString(path)) {
					try {
						return Integer.parseInt(config.getString(path));
					} catch(NumberFormatException e) {}
				} else if(config.isDouble(path)) {
					return (int)config.getDouble(path);
				}
			}
			return def;
		}
		public double optDouble(String path, double def) {
			if(config.contains(path)) {
				if(config.isDouble(path)) {
					return config.getDouble(path);
				} else if(config.isString(path)) {
					try {
						return Double.parseDouble(config.getString(path));
					} catch(NumberFormatException e) {}
				} else if(config.isInt(path)) {
					return (double)config.getInt(path);
				}
			}
			return def;
		}
		public void set(String path, Object arg) {
			config.set(path, arg);
		}
		public boolean save() {
			String data = config.saveToString();
			
			Matcher mat = Pattern.compile("\\\\u([0-9a-f]{4})").matcher(data);
			while(mat.find()) {
				String uni = new String(new int[]{Integer.parseInt(mat.group(1), 16)}, 0, 1);
				data = data.replace("\\u"+mat.group(1), uni);
			}
			data = data.replace("\\xa7", "��").replaceAll("\\\\\\n *", "");
			try {
				OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(file), "SJIS");
				writer.write(data);
				writer.close();
				return true;
			} catch(IOException ex) {
				return false;
			}
		}
		public boolean reload() {
			try {
				save();
				config.load(file);
				return true;
			} catch (IOException | InvalidConfigurationException e) {
				return false;
			}
		}
		public Set<String> getKeys(String path) {
			return config.getConfigurationSection(path).getKeys(false);
		}
		public boolean contains(String path) {
			return config.contains(path);
		}
	}
	public static class ConfigNotFoundException extends Exception{
		private static final long serialVersionUID = -4183390338320843307L;
		public ConfigNotFoundException(){
			super();
		}
	}
	public static void sendAnnounce(String path, Player p) {
		sendAnnounce(path , p, null, -1);
	}
	public static void sendAnnounce(String path, Player p, Player t) {
		sendAnnounce(path , p, t.getName(), -1);
	}
	public static void sendAnnounce(String path, Player p, String t) {
		sendAnnounce(path , p, t, -1);
	}
	public static void sendAnnounce(String path, Player p, String t, int time) {
		if(HIYU_TosoGame.read){
			Config config = HIYU_TosoGame.message;
			if(config.contains(path)) {
				//Message
				String message = null;
				try {
					message = config.getString(path+".Message");
					if(time != -1) {
						message = message.replace("%s", String.valueOf(time));
					}
					if(p != null) {
						message = message.replace("%player", p.getName());
					}
					if(t != null) {
						message = message.replace("%target", t);
					}
				}catch(ConfigNotFoundException e){}
				try {
					boolean bm = config.getBoolean(path+".BroadcastMessage");
					if(message != null) {
						if(bm) {
							Bukkit.broadcastMessage(message);
						} else {
							if(p != null) {
								p.sendMessage(message);
							}
						}
					}
				}catch(ConfigNotFoundException e){}
				
				//Sound
				try {
					String arg = config.getString(path+".Sound");
					String name = "none";
					float vol = 1f;
					float pit = 1f;
					String[] args = arg.split(" ");
					try{
						name = args[0];
						vol = Float.parseFloat(args[1]);
						pit = Float.parseFloat(args[2]);
					}catch(ArrayIndexOutOfBoundsException | NumberFormatException e){}
					if(!name.equalsIgnoreCase("none")) {
						try {
							boolean bs = config.getBoolean(path+".BroadcastSound");
							if(bs) {
								for(Player o : getOnlinePlayers()){
									PlaySoundAPI.playSound(o, name, o.getLocation(), vol, pit);
								}
							} else {
								if(p != null) {
									PlaySoundAPI.playSound(p, name, p.getLocation(), vol, pit);
								}
							}
						}catch(ConfigNotFoundException e){}
					}
					
				}catch(ConfigNotFoundException e){}
			}
			
		}
	}
	public static Player[] getOnlinePlayers(){
		try{
			return Bukkit.getOnlinePlayers().toArray(new Player[0]);
		}catch(NoSuchMethodError e){
			try{
				Method getOnlinePlayers = null;
				for(Method m : Bukkit.class.getDeclaredMethods()){
					if(m.getName().equals("getOnlinePlayers")){
						getOnlinePlayers = m;
						break;
					}
				}
				if(getOnlinePlayers == null) return new Player[]{};
				Object OnlinePlayers = getOnlinePlayers.invoke(Bukkit.class, new Object[0]);
				if(OnlinePlayers instanceof Player[]) return (Player[])OnlinePlayers;
			}catch (Exception es){}
			return new Player[]{};
		}
	}
	public static class BlockType{
		public static boolean isPassBlock(Block b){
			switch(b.getType()){
			case AIR: return true;
			case SAPLING: return true;
			case LONG_GRASS: return true;
			case DEAD_BUSH: return true;
			case YELLOW_FLOWER: return true;
			case RED_ROSE: return true;
			case BROWN_MUSHROOM: return true;
			case RED_MUSHROOM: return true;
			case DOUBLE_PLANT: return true;
			case WATER_LILY: return true;
			case SNOW: return true;

			case WALL_BANNER: return true;
			case STANDING_BANNER: return true;
			case WALL_SIGN: return true;
			case SIGN_POST: return true;
			case CARPET: return true;
			case TORCH: return true;

			case RAILS: return true;
			case POWERED_RAIL: return true;
			case DETECTOR_RAIL: return true;
			case ACTIVATOR_RAIL: return true;

			case LEVER: return true;
			case STONE_BUTTON: return true;
			case WOOD_BUTTON: return true;
			case STONE_PLATE: return true;
			case WOOD_PLATE: return true;
			case GOLD_PLATE: return true;
			case IRON_PLATE: return true;
			case TRAP_DOOR: return true;
			case IRON_TRAPDOOR: return true;
			case TRIPWIRE_HOOK: return true;
			case REDSTONE_TORCH_ON: return true;
			case REDSTONE_TORCH_OFF: return true;
			case DIODE_BLOCK_OFF: return true;
			case REDSTONE_COMPARATOR_OFF: return true;
			case DIODE_BLOCK_ON: return true;
			case REDSTONE_COMPARATOR_ON: return true;
			default: return false;
			}
		}
		public static boolean isWallBlock(Block b){
			return !isPassBlock(b);
		}
		public static boolean isTallBlock(Block b){
			switch(b.getType()){
			case FENCE: return true;
			case FENCE_GATE: return true;
			case SPRUCE_FENCE: return true;
			case SPRUCE_FENCE_GATE: return true;
			case BIRCH_FENCE: return true;
			case BIRCH_FENCE_GATE: return true;
			case JUNGLE_FENCE: return true;
			case JUNGLE_FENCE_GATE: return true;
			case DARK_OAK_FENCE: return true;
			case DARK_OAK_FENCE_GATE: return true;
			case ACACIA_FENCE: return true;
			case ACACIA_FENCE_GATE: return true;
			case COBBLE_WALL: return true;
			default: return false;
			}
		}
		public static boolean isLowerHalfBlock(Block b){
			switch(b.getType()){
			case STEP: return isLowerHalf(b);
			case WOOD_STEP: return isLowerHalf(b);
			case STONE_SLAB2: return isLowerHalf(b);
			default: return false;
			}
		}
		public static boolean isUpperHalfBlock(Block b){
			switch(b.getType()){
			case STEP: return isUpperHalf(b);
			case WOOD_STEP: return isUpperHalf(b);
			case STONE_SLAB2: return isUpperHalf(b);
			default: return false;
			}
		}
		public static boolean isLiquidBlock(Block b){
			switch(b.getType()){
			case WATER: return true;
			case STATIONARY_WATER: return true;
			case LAVA: return true;
			case STATIONARY_LAVA: return true;
			default: return false;
			}
		}
		@SuppressWarnings("deprecation")
		private static boolean isLowerHalf(Block b){
			int d = (int)b.getData();
			return d < 8;
		}
		@SuppressWarnings("deprecation")
		private static boolean isUpperHalf(Block b){
			int d = (int)b.getData();
			return d > 7;
		}
	}
}
