package com.github.keepoff07.hiyutosogame.utile;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class PlaySoundAPI {
	private static String PackageName;
	static {
		String version = Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
		PackageName = "net.minecraft.server."+version;
	}
	public static boolean playSound(Player player, String sound, Location location, float vol, float pitch) {
		try {
			sendPacket(player, newSoundEffect(sound, location, vol, pitch));
			return true;
		} catch(Throwable e) {
			return false;
		}
	}
	public static boolean playSound(World world, String sound, Location location, float vol, float pitch) {
		try {
			Object packet = newSoundEffect(sound, location, vol, pitch);
			for(Player player : getOnlinePlayers()) {
				if(player.getWorld().equals(world)) {
					sendPacket(player, packet);
				}
			}
			return true;
		} catch(Throwable e) {
			return false;
		}
	}
	private static Class<?> getCraftClass(String s) throws Exception {
		Class<?> craftclass = Class.forName(PackageName+"."+s);
		return craftclass;
	}
	private static Object newSoundEffect(String sound, Location location, float vol, float pitch) throws Exception {
		Class<?> a = getCraftClass("PacketPlayOutNamedSoundEffect");
		Constructor<?> b = a.getConstructor(new Class<?>[]{String.class, double.class, double.class, double.class, float.class, float.class});
		Object PacketPlayOutNamedSoundEffect = b.newInstance(new Object[]{sound, location.getX(), location.getY(), location.getZ(), vol, pitch});
		return PacketPlayOutNamedSoundEffect;
	}
	private static void sendPacket(Player player, Object packet) throws Exception {
		Method PlayerHandle = player.getClass().getMethod("getHandle");
		Object EntityPlayer = PlayerHandle.invoke(player);
		Object PlayerConnection = EntityPlayer.getClass().getField("playerConnection").get(EntityPlayer);
		Method sendPacket = null;
		for(Method m : PlayerConnection.getClass().getDeclaredMethods()){
			if(m.getName().equals("sendPacket")){
				sendPacket = m;
				break;
			}
		}
		sendPacket.invoke(PlayerConnection, packet);
	}
	private static Player[] getOnlinePlayers(){
		try{
			return Bukkit.getOnlinePlayers().toArray(new Player[0]);
		}catch(NoSuchMethodError e){
			try{
				Method getOnlinePlayers = null;
				for(Method m : Bukkit.class.getDeclaredMethods()){
					if(m.getName().equals("getOnlinePlayers")){
						getOnlinePlayers = m;
						break;
					}
				}
				if(getOnlinePlayers == null) return new Player[]{};
				Object OnlinePlayers = getOnlinePlayers.invoke(Bukkit.class, new Object[0]);
				if(OnlinePlayers instanceof Player[]) return (Player[])OnlinePlayers;
			}catch (Exception es){}
			return new Player[]{};
		}
	}
}
