/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.command.TCGameMode;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.FoodLevel;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard.Team;
import com.github.keepoff07.hiyutosogame.utile.Utility.BlockType;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TLPlayerControl implements Listener{

	//#Request11
	@EventHandler
	public void onPlayerToggleSprint(PlayerToggleSprintEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(TosoGameAPI.isHunterPlayer(p)){
				try{
					if(p.isSprinting()) {
						p.setWalkSpeed((float)HIYU_TosoGame.config.getDouble("HunterPlayer.WalkSpeed"));
					} else {
						p.setWalkSpeed((float)HIYU_TosoGame.config.getDouble("HunterPlayer.SprintSpeed"));
					}
					return;
				}catch(ConfigNotFoundException | IllegalArgumentException ex){
					p.setWalkSpeed(0.2f);
				}
			} else if(TosoGameAPI.isTosoPlayer(p) & !TosoGameAPI.isCaughtPlayer(p)){
				try{
					if(p.isSprinting()) {
						p.setWalkSpeed((float)HIYU_TosoGame.config.getDouble("TosoPlayer.WalkSpeed"));
					} else {
						p.setWalkSpeed((float)HIYU_TosoGame.config.getDouble("TosoPlayer.SprintSpeed"));
					}
					return;
				}catch(ConfigNotFoundException | IllegalArgumentException ex){
					p.setWalkSpeed(0.2f);
				}
			} else {
				p.setWalkSpeed(0.2f);
			}
		}
	}
	//#Request11
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onPlayerJump(PlayerMoveEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			Location from = e.getFrom();
			if(!TosoTimer.onGame) return;
			if(p.isSprinting() && !p.isOnGround() && e.getTo().getY() > from.getY()+0.2d){
				if(TosoGameAPI.isHunterPlayer(p)){
					try{
						if(!HIYU_TosoGame.config.getBoolean("HunterPlayer.Jump")) {
							e.setTo(from);
						}
						return;
					}catch(ConfigNotFoundException ex){}
				} else if(TosoGameAPI.isTosoPlayer(p) & !TosoGameAPI.isCaughtPlayer(p)){
					try{
						if(!HIYU_TosoGame.config.getBoolean("TosoPlayer.Jump")) {
							e.setTo(from);
						}
						return;
					}catch(ConfigNotFoundException ex){}
				}
			}
		}
	}
	//#Request9
	@EventHandler
	public void onPlayerFallDamage(EntityDamageEvent e){
		if(HIYU_TosoGame.read){
			Entity ent = e.getEntity();
			if(ent instanceof Player && e.getCause().equals(DamageCause.FALL)){
				Player p = (Player)ent;
				if(!TosoTimer.onGame){
					e.setCancelled(true);
					return;
				}
				if(TosoGameAPI.isHunterPlayer(p) | (TosoGameAPI.isTosoPlayer(p) & !TosoGameAPI.isCaughtPlayer(p))){
					PotionEffect ef1 = TosoGameAPI.getPotionEffect(PotionEffectType.BLINDNESS, HIYU_TosoGame.config, "FallDamagePenalty");
					PotionEffect ef2 = TosoGameAPI.getPotionEffect(PotionEffectType.CONFUSION, HIYU_TosoGame.config, "FallDamagePenalty");
					PotionEffect ef3 = TosoGameAPI.getPotionEffect(PotionEffectType.SLOW, HIYU_TosoGame.config, "FallDamagePenalty");
					if(ef1 != null) p.addPotionEffect(ef1);
					if(ef2 != null) p.addPotionEffect(ef2);
					if(ef3 != null) p.addPotionEffect(ef3);
					e.setCancelled(true);
				} else if(TosoGameAPI.isTosoPlayer(p)){
					e.setCancelled(true);
				}
			}
		}
	}
	//#Request1
	@EventHandler
	public void onBlockBreak(BlockBreakEvent e){
		if(HIYU_TosoGame.read){
			final Player p = e.getPlayer();
			if(!TosoGameAPI.isAdmin(p)){
				e.setCancelled(true);
				String path = null;
				if(TosoScoreBoard.isTosoPlayer(p, false)) {
					path = "TosoPlayer.AntiBlockGlitch";
				} else if(TosoScoreBoard.isHunterPlayer(p)) {
					path = "HunterPlayer.AntiBlockGlitch";
				}
				if(path != null) {
					try {
						if(HIYU_TosoGame.config.getBoolean(path)) {
							Block b = e.getBlock();
							if(isBlock(b)) {
								Location pl = p.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
								new KeepOut(p, pl).runTaskTimer(HIYU_TosoGame.plugin, 10, 2);
							}
						}
					}catch(ConfigNotFoundException ex){}
				}
			}
		}
	}
	@EventHandler
	public void onBlockPlace(BlockPlaceEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(!TosoGameAPI.isAdmin(p)){
				e.setCancelled(true);
			}
		}
	}
	@EventHandler
	public void onPlayerDropItem(PlayerDropItemEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(!TosoGameAPI.isAdmin(p)){
				e.setCancelled(true);
			}
		}
	}
	@EventHandler
	public void onPlayerToggleSprintFoodChange(PlayerToggleSprintEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(e.isSprinting()) {
				FoodLevel.FoodReduce(p);
			} else {
				FoodLevel.FoodHeal(p);
			}
		}
	}
	@EventHandler
	public void onFoodLevel(FoodLevelChangeEvent e){
		e.setCancelled(true);
	}
	@EventHandler(priority=EventPriority.HIGH)
	public void onPlayerChat(AsyncPlayerChatEvent e){
		Player p = e.getPlayer();
		Team t = TosoScoreBoard.getTSTeam(p);
		if(t != null){
			String format = t.getFormat().replace("%player", "%1$s").replace("%message", "%2$s");
			e.setFormat(format);
		}
	}
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e){
		if(HIYU_TosoGame.read){
			TosoTimer.setSideBar();
			final Player p = e.getPlayer();
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
				@Override
				public void run() {
					for (Player online : Bukkit.getServer().getOnlinePlayers()) {
						if (TCGameMode.hides.contains(online.getName())) {
							p.hidePlayer(online);
						}
					}
				}
			}, 2l);
		}
	}
	@EventHandler(priority=EventPriority.LOW)
	public void onPlayerSendItem(PlayerJoinEvent event){
		if(HIYU_TosoGame.read){
			Player player = event.getPlayer();
			loginSendItems(player);
		}
	}
	public static void loginSendItems(Player player) {
		Config config = HIYU_TosoGame.items;
		if(config.optBoolean("LoginSendItems.Enable", false)) {
			PlayerInventory inv = player.getInventory();
			for(int i = 0; i < 36; i++) {
				String path = "LoginSendItems.slot"+i;
				try {
					int id = config.getInt(path+".ItemID");
					int da = config.getInt(path+".Damage");
					int co = config.getInt(path+".Count");
					@SuppressWarnings("deprecation")
					ItemStack item = new ItemStack(id, co,(short)da);
					inv.setItem(i, item);
				} catch(ConfigNotFoundException ex) {
					continue;
				}
			}
		}
	}
	@EventHandler
	public void onPlayerLogout(PlayerQuitEvent e){
		if(HIYU_TosoGame.read){
			TosoTimer.setSideBar();
		}
	}
	@EventHandler
	public void onChickenSpawn(CreatureSpawnEvent e){
		EntityType type = e.getEntityType();
		if(type.equals(EntityType.CHICKEN)) e.setCancelled(true);
	}
	@EventHandler
	public void onOpenContainer(PlayerInteractEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			switch(e.getAction()) {
			case RIGHT_CLICK_BLOCK:
				Block b = e.getClickedBlock();
				Config c = HIYU_TosoGame.config;
				switch(b.getType()) {
				case CHEST:
				case TRAPPED_CHEST:
					if(!enableOpen(c,p,"Chest")) e.setCancelled(true);
					break;
				case FURNACE:
				case BURNING_FURNACE:
					if(!enableOpen(c,p,"Furnace")) e.setCancelled(true);
					break;
				case ENCHANTMENT_TABLE:
					if(!enableOpen(c,p,"EnchantTable")) e.setCancelled(true);
					break;
				case DISPENSER:
					if(!enableOpen(c,p,"Dispenser")) e.setCancelled(true);
					break;
				case DROPPER:
					if(!enableOpen(c,p,"Dropper")) e.setCancelled(true);
					break;
				case HOPPER:
					if(!enableOpen(c,p,"Hopper")) e.setCancelled(true);
					break;
				case BREWING_STAND:
					if(!enableOpen(c,p,"BrewingStand")) e.setCancelled(true);
					break;
				case BEACON:
					if(!enableOpen(c,p,"Beacon")) e.setCancelled(true);
					break;
				default: return;
				}
			default: return;
			}
		}
	}
	public boolean enableOpen(Config c, Player p, String path) {
		if(TosoGameAPI.isTosoPlayer(p)) {
			return c.optBoolean("TosoPlayer.Blocks."+path+".Open", false);
		} else if(TosoGameAPI.isHunterPlayer(p)) {
			return c.optBoolean("HunterPlayer.Blocks."+path+".Open", false);
		}
		return true;
	}
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e) {
		if(!HIYU_TosoGame.read) return;
		Player p = (Player)e.getWhoClicked();
		Inventory inv = e.getInventory();
		Config c = HIYU_TosoGame.config;
		int s = e.getRawSlot();
		boolean air = e.getCursor().getType().equals(Material.AIR);
		switch(inv.getType()) {
		case ANVIL:
			break;
		case BEACON:
			if(!enableTD(c, p, "Beacon", s, 0, air))
				e.setCancelled(true);
			break;
		case BREWING:
			if(!enableTD(c, p, "BrewingStand", s, 3, air))
				e.setCancelled(true);
			break;
		case CHEST:
			int co = 26;
			if(inv.getHolder() != null) {
				if(inv.getHolder().getClass().getName().endsWith("DoubleChest"))
					co = 53;
				if(!enableTD(c, p, "Chest", s, co, air))
					e.setCancelled(true);
			}
			break;
		case DISPENSER:
			if(!enableTD(c, p, "Dispenser", s, 8, air))
				e.setCancelled(true);
			break;
		case DROPPER:
			if(!enableTD(c, p, "Dropper", s, 8, air))
				e.setCancelled(true);
			break;
		case ENCHANTING:
			if(!enableTD(c, p, "EnchantTable", s, 0, air))
				e.setCancelled(true);
			break;
		case ENDER_CHEST:
			break;
		case FURNACE:
			if(!enableTD(c, p, "Furnace", s, 2, air))
				e.setCancelled(true);
			break;
		case HOPPER:
			if(!enableTD(c, p, "Hopper", s, 4, air))
				e.setCancelled(true);
			break;
		case WORKBENCH:
			break;
		default:
			break;
		}
	}
	public boolean enableTD(Config c, Player p, String path, int cs, int max, boolean air) {
		if(cs < 0 || !air) return true;
		else if(cs <= max) { //Take
			if(TosoGameAPI.isTosoPlayer(p)) {
				return c.optBoolean("TosoPlayer.Blocks."+path+".Take", false);
			} else if(TosoGameAPI.isHunterPlayer(p)) {
				return c.optBoolean("HunterPlayer.Blocks."+path+".Take", false);
			}
		} else { //Deliver
			if(TosoGameAPI.isTosoPlayer(p)) {
				return c.optBoolean("TosoPlayer.Blocks."+path+".Deliver", false);
			} else if(TosoGameAPI.isHunterPlayer(p)) {
				return c.optBoolean("HunterPlayer.Blocks."+path+".Deliver", false);
			}
		}
		return true;
	}
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onAdminCompass(PlayerInteractEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(p.getGameMode().equals(GameMode.CREATIVE) &&
					p.getItemInHand().getType().equals(Material.COMPASS)){
				if(e.getAction().equals(Action.LEFT_CLICK_BLOCK)){
					e.setCancelled(true);
					Block b = e.getClickedBlock();
					Location l = getTPPoint(b, p);
					if(l != null) p.teleport(l);
					return;
				}else if(e.getAction().equals(Action.LEFT_CLICK_AIR)){
					e.setCancelled(true);
					Block b = p.getTargetBlock(null, 500);
					Location l = getTPPoint(b, p);
					if(l != null) p.teleport(l);
					return;
				}else if(e.getAction().equals(Action.RIGHT_CLICK_BLOCK)){
					e.setCancelled(true);
					Location l = getWallTPPoint(e.getClickedBlock(),e.getBlockFace() , p);
					if(l != null) p.teleport(l);
					return;
				}
			}
		}
	}
	private Location getTPPoint(Block b, Player p){
		Location l = b.getLocation().add(0.5d, 0.5d, 0.5d);
		if(l.getBlockY() >= 125) return null;
		while(!isEnmpty(l)){
			if(l.getBlockY() != 125)
				l = l.clone().add(0d, 1.0d, 0d);
			else return null;
		}
		l.setYaw(p.getLocation().getYaw());
		l.setPitch(p.getLocation().getPitch());
		return l;
	}
	private boolean isEnmpty(Location l){
		Block b = l.getBlock();
		Material m1 = b.getType();
		Material m2 = b.getRelative(BlockFace.UP).getType();
		Material m3 = b.getRelative(BlockFace.DOWN).getType();
		return m1.equals(Material.AIR) && m2.equals(Material.AIR) && !m3.equals(Material.AIR);
	}
	private Location getWallTPPoint(Block b, BlockFace f, Player p){
		BlockFace a = gyaku(f);
		Block o = b.getRelative(a);
		if(!(a.equals(BlockFace.UP)|a.equals(BlockFace.DOWN))){
			o = o.getRelative(BlockFace.DOWN);
		}
		int max = 0;
		while(!isWallEnmpty(o.getLocation())){
			max++;
			if(max != 100){
				o = o.getRelative(a);
				if(o.getLocation().getBlockY() == 255){
					return null;
				}
			}
			else return null;
		}
		Location l = o.getLocation().add(0.5d, 0d, 0.5d);
		l.setYaw(p.getLocation().getYaw());
		l.setPitch(p.getLocation().getPitch());
		return l;
	}
	private BlockFace gyaku(BlockFace f){
		switch (f) {
		case UP: return BlockFace.DOWN;
		case DOWN: return BlockFace.UP;
		case EAST: return BlockFace.WEST;
		case WEST: return BlockFace.EAST;
		case NORTH: return BlockFace.SOUTH;
		case SOUTH: return BlockFace.NORTH;
		default: return BlockFace.UP;
		}
	}
	private boolean isWallEnmpty(Location l){
		if(l.getY() < 1d) return false;
		Block b = l.getBlock();
		Material m1 = b.getType();
		Material m2 = b.getRelative(BlockFace.UP).getType();
		return m1.equals(Material.AIR) && m2.equals(Material.AIR);
	}
	private static boolean isBlock(Block b){
		return !(BlockType.isPassBlock(b) | BlockType.isLiquidBlock(b));
	}
	public static class KeepOut extends BukkitRunnable{
		Player p;
		Location l;
		int time;
		public KeepOut(Player p, Location l) {
			this.p = p;
			this.l = l;
			time = 4;
		}
		@Override
		public void run() {
			time--;
			if(time == 0) this.cancel();
			Location pl = p.getLocation();
			l.setYaw(pl.getYaw());
			l.setPitch(pl.getPitch());
			p.teleport(l);
		}

	}
	@EventHandler
	public void onPlayerRespawn(PlayerRespawnEvent e) {
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(TosoGameAPI.isTosoPlayer(p) | TosoGameAPI.isSuccessPlayer(p)) {
				Location l = TosoGameAPI.getJailLocation();
				if(l != null) e.setRespawnLocation(l);
				TosoGameAPI.addCaughtPlayer(p);
			} else if(TosoGameAPI.isCaughtPlayer(p)) {
				Location l = TosoGameAPI.getJailLocation();
				if(l != null) e.setRespawnLocation(l);
			} else if(TosoGameAPI.isHunterPlayer(p)) {
				Location l = TosoGameAPI.getGatherLocation();
				if(l != null) e.setRespawnLocation(l);
			}
		}
	}
}