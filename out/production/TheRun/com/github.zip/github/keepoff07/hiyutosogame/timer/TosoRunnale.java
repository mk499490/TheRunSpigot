/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.timer;

import org.bukkit.scheduler.BukkitRunnable;

import com.github.keepoff07.hiyutosogame.listener.TLMission;
import com.github.keepoff07.hiyutosogame.utile.Utility;

public class TosoRunnale extends BukkitRunnable{

	private int countdown;
	private int gametime;
	public TosoRunnale(int cd, int game){
		this.countdown = cd;
		this.gametime = game;
	}
	@Override
	public void run() {
		if(!(TosoTimer.onGame|TosoTimer.onGame2)) return;
		if(countdown <= 0){
			gametime--;
			TosoTimer.sendMoney();
			TosoTimer.setSideBar(countdown, gametime);
			if(TLMission.BLOCKING_TIME > 0) {
				int BLOCKING_LATE = gametime - TLMission.BLOCKING_TIME;
				if(BLOCKING_LATE <= 0) {
					TLMission.failedBlocking(BLOCKING_LATE);
				} else {
					TLMission.announceBlocking(BLOCKING_LATE);
				}
			}
			if(gametime == 0){
				TosoTimer.endTimer();
				Utility.sendAnnounce("TimeAnnounce.TimerEnd", null);
				return;
			} else if(gametime <= 10 || gametime == 30 || gametime == 60 || gametime == 180 || gametime == 300){
				Utility.sendAnnounce("TimeAnnounce.Timer", null, null, gametime);
			}
		} else {
			countdown--;
			TosoTimer.setSideBar(countdown, gametime);
			if(countdown == 0){
				Utility.sendAnnounce("TimeAnnounce.TimerStart", null);
				TosoTimer.timerStartAction();
				TosoTimer.onGame = true;
				return;
			} else if(countdown <= 10 || countdown == 30 || countdown == 60){
				Utility.sendAnnounce("TimeAnnounce.CountDown", null, null, countdown);
			}
		}
	}
}
