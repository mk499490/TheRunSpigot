/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Egg;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Snowball;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.command.TosoCommands;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TLHunterPlayer implements Listener{

	@EventHandler
	public void onHunterCatch(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Player && attent instanceof Player){
				final Player att = (Player)attent;
				final Player def = (Player)defent;
				if(TosoTimer.onGame && TosoGameAPI.isHunterPlayer(att) &&
						(TosoGameAPI.isTosoPlayer(def) & !TosoGameAPI.isCaughtPlayer(def))){
					if(def.hasPotionEffect(PotionEffectType.INVISIBILITY)){
						e.setCancelled(true);
						return;
					} else {
						e.setDamage(0d);
						TosoGameAPI.addCaughtPlayer(def);
						catchlist.add(att.getName());
						Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable(){
							@Override
							public void run() {
								catchlist.remove(att.getName());
								Location l = TosoGameAPI.getJailLocation();
								if(l != null) def.teleport(l);
								Utility.sendAnnounce("HunterPlayer.Catch", att, def);
								Utility.sendAnnounce("TosoPlayer.Catch", def, att);
							}
						}, 60l);
					}
				} else {
					e.setCancelled(true);
				}
			}
		}
	}

	@EventHandler
	public void onPlayerMove(PlayerMoveEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			Location a = e.getFrom();
			Location b = e.getTo();
			if((isFenceStop(p)|isCatchStop(p))&& TosoGameAPI.isHunterPlayer(p)){
				if(a.getBlockX() != b.getBlockX() | a.getBlockZ() != b.getBlockZ()){
					e.setTo(a);
				}
			}
		}
	}
	//#Request7
	@EventHandler
	public void onHunterDamageEgg(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Player && attent instanceof Egg){
				Player def = (Player)defent;
				if(TosoTimer.onGame && TosoGameAPI.isHunterPlayer(def)){
					if(!def.hasPotionEffect(PotionEffectType.DAMAGE_RESISTANCE)){
						PotionEffect ef1 = TosoGameAPI.getPotionEffect(PotionEffectType.BLINDNESS,"ItemSetting");
						PotionEffect ef2 = TosoGameAPI.getPotionEffect(PotionEffectType.DAMAGE_RESISTANCE,"ItemSetting");
						if(ef1 != null) def.addPotionEffect(ef1);
						if(ef2 != null) def.addPotionEffect(ef2);
						Utility.sendAnnounce("HunterPlayer.Hit_Blindness", def);
						ProjectileSource pro = ((Egg)attent).getShooter();
						if(pro instanceof Player){
							Utility.sendAnnounce("TosoPlayer.Hit_Blindness", (Player)pro);
						}
					}
					else e.setCancelled(true);
				} else {
					e.setCancelled(true);
				}
			}
		}
	}
	//#Request10
	@EventHandler
	public void onHunterDamageSnowball(EntityDamageByEntityEvent e){
		if(HIYU_TosoGame.read){
			Entity defent = e.getEntity();
			Entity attent = e.getDamager();
			if(defent instanceof Player && attent instanceof Snowball){
				Player def = (Player)defent;
				if(TosoTimer.onGame && TosoGameAPI.isHunterPlayer(def)){
					if(!isFenceStop(def)){
						ironfence(def);
						Utility.sendAnnounce("HunterPlayer.Hit_Snowball", def);
						ProjectileSource pro = ((Snowball)attent).getShooter();
						if(pro instanceof Player){
							Utility.sendAnnounce("TosoPlayer.Hit_Snowball", (Player)pro);
						}
					} else e.setCancelled(true);
				} else {
					e.setCancelled(true);
				}
			}
		}
	}
	@EventHandler
	public void onArmorClick(InventoryClickEvent e){
		Player p = (Player)e.getWhoClicked();
		if(e.getSlotType().equals(InventoryType.SlotType.ARMOR) && TosoGameAPI.isHunterPlayer(p)) {
			e.setCancelled(true);
			p.closeInventory();
		}
	}
	@EventHandler
	public void onPlayerLeft(PlayerQuitEvent e) {
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(TosoGameAPI.isHunterPlayer(p)) {
				Player s = HunterSupport();
				if(s != null) {
					s.getInventory().clear();
					TosoGameAPI.addHunterPlayer(s);
					Location d = TosoGameAPI.getGatherLocation();
					if(d != null) s.teleport(d);
					Utility.sendAnnounce("Hunter.Support", s, p);
				} else {
					TosoCommands.GameReset();
					return;
				}
				Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable(){
					@Override
					public void run() {
						TosoTimer.setSideBar();
					}
				}, 2l);
			}
		}
	}
	void ironfence(Player p){
		if(!isFenceStop(p)){
			long time = 100;
			try{
				time = HIYU_TosoGame.items.getInt("SnowballCoolTime") * 20;
			}catch(ConfigNotFoundException e){}
			final Player fp = p;
			fencelist.add(p.getName());
			final int i = place(p.getLocation());
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable(){
				@Override
				public void run() {
					fencelist.remove(fp.getName());
					replace(i);
				}
			}, time);
		}
	}
	List<String> fencelist = new ArrayList<String>();
	Map<Integer, Location[][][]> fence = new HashMap<Integer, Location[][][]>();
	int place(Location l){
		int i = 0;
		while(fence.containsKey(Integer.valueOf(i))){
			i++;
		}
		Location[][][] locs = new Location[3][3][3];
		World w = l.getWorld();
		int cx = 0;
		for(int x = l.getBlockX()-1; x < l.getBlockX()+2; x++){
			int cy = 0;
			for(int y = l.getBlockY()-1; y < l.getBlockY()+2; y++){
				int cz = 0;
				for(int z = l.getBlockZ()-1; z < l.getBlockZ()+2; z++){
					if(x == l.getBlockX() && z == l.getBlockZ()){
						locs[cx][cy][cz] = null;
						continue;
					}
					Location loc = new Location(w,x,y,z);
					Block b = loc.getBlock();
					if(b.getType().equals(Material.AIR)){
						b.setType(Material.IRON_FENCE);
						locs[cx][cy][cz] = loc;
					} else {
						locs[cx][cy][cz] = null;
					}
					cz++;
				}
				cy++;
			}
			cx++;
		}
		fence.put(Integer.valueOf(i), locs);
		return i;
	}
	void replace(int i){
		if(fence.containsKey(Integer.valueOf(i))){
			Location[][][] locs = fence.get(Integer.valueOf(i));
			for(int x = 0; x < 3; x++){
				for(int y = 0; y < 3; y++){
					for(int z = 0; z < 3; z++){
						Location loc = locs[x][y][z];
						if(loc != null){
							loc.getBlock().setType(Material.AIR);
						}
					}
				}
			}
		}
	}
	boolean isFenceStop(Player p){
		return fencelist.contains(p.getName());
	}
	List<String> catchlist = new ArrayList<String>();
	boolean isCatchStop(Player p){
		return catchlist.contains(p.getName());
	}
	public static Player HunterSupport() {
		List<Player> l = new ArrayList<Player>();
		for(Player p : Bukkit.getOnlinePlayers()) {
			if(!TosoGameAPI.isAdmin(p) && !TosoGameAPI.isHunterPlayer(p)) {
				l.add(p);
			}
		}
		if(!l.isEmpty()) {
			Random r = new Random();
			return l.get(r.nextInt(l.size()));
		} else {
			return null;
		}
	}
}
