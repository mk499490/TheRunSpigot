/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.utile;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TosoScoreBoard {
	static Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
	public static Team admin = null;
	public static Team toso = null;
	public static Team jail = null;
	public static Team suc = null;
	public static Team hunter = null;
	
	public static void reset() {
		if(HIYU_TosoGame.read){
			for(org.bukkit.scoreboard.Team t : scoreboard.getTeams()){
				t.unregister();
			}
			Config teams = HIYU_TosoGame.teams;
			admin = create(teams, "Admin", "admin");
			toso = create(teams, "TosoPlayer", "toso");
			jail = create(teams, "CaughtPlayer", "jail");
			suc = create(teams, "SuccessPlayer", "success");
			hunter = create(teams, "HunterPlayer", "hunter");
			for(Player p : Utility.getOnlinePlayers()){
				addAdmin_AUTO(p);
			}
			TosoTimer.setSideBar();
		}
	}
	private static Team create(Config config, String path, String name) {
		Team team = new Team();
		org.bukkit.scoreboard.Team st = scoreboard.getTeam(name);
		if(st != null) st.unregister();
		st = scoreboard.registerNewTeam(name);
		st.setAllowFriendlyFire(true);
		st.setCanSeeFriendlyInvisibles(true);
		try {
			st.setPrefix(config.getString(path+".Prefix"));
		}catch(ConfigNotFoundException e){}
		try {
			st.setSuffix(config.getString(path+".Suffix"));
		}catch(ConfigNotFoundException e){}
		try {
			team.setFormat(config.getString(path+".ChatFormat"));
		}catch(ConfigNotFoundException e){}
		team.setTeam(st);
		return team;
	}
	public static class Team {
		private org.bukkit.scoreboard.Team team = null;
		private String format = "<%player> %message";
		public org.bukkit.scoreboard.Team getTeam(){
			return this.team;
		}
		public void setTeam(org.bukkit.scoreboard.Team team){
			this.team = team;
		}
		public String getFormat(){
			return this.format;
		}
		public void setFormat(String arg){
			this.format = arg;
		}
		public void addPlayer(Player player){
			if(team != null) this.team.addPlayer((OfflinePlayer)player);
		}
		public void addPlayer(OfflinePlayer player){
			if(team != null) this.team.addPlayer(player);
		}
		public void removePlayer(Player player){
			if(team != null) this.team.removePlayer((OfflinePlayer)player);
		}
		public List<Player> clearPlayers(){
			if(team != null) {
				List<Player> l = new ArrayList<Player>();
				for(OfflinePlayer o : this.team.getPlayers()){
					this.team.removePlayer(o);
					if(o.isOnline()) l.add((Player)o);
				}
				return l;
			} else return new ArrayList<Player>();
		}
		public boolean equals(org.bukkit.scoreboard.Team t){
			if(team != null && t != null) return team.getName().equals(t.getName());
			else return false;
		}
	}
	private static org.bukkit.scoreboard.Team getTeam(Player player) {
		return scoreboard.getPlayerTeam(player);
	}
	public static Team getTSTeam(Player player) {
		if(isAdminPlayer(player)) return admin;
		else if(isTosoPlayer(player, true)) return toso;
		else if(isCaughtPlayer(player)) return jail;
		else if(isSuccessPlayer(player)) return suc;
		else if(isHunterPlayer(player)) return hunter;
		else return null;
	}
	private static boolean joinTeam(Player player) {
		return scoreboard.getPlayerTeam(player) != null;
	}
	public static boolean isTosoPlayer(Player p, boolean div){
		org.bukkit.scoreboard.Team t = getTeam(p);
		if(div) return toso.equals(t);
		else {
			return toso.equals(t) | jail.equals(t) | suc.equals(t);
		}
	}
	public static boolean isCaughtPlayer(Player player){
		return jail.equals(getTeam(player));
	}
	public static boolean isSuccessPlayer(Player player){
		return suc.equals(getTeam(player));
	}
	public static boolean isHunterPlayer(Player player){
		return hunter.equals(getTeam(player));
	}
	public static boolean isAdminPlayer(Player player){
		return player.isOp();
	}
	public static void addTosoPlayer(Player player){
		toso.addPlayer(player);
	}
	public static void addCaughtPlayer(Player player){
		jail.addPlayer(player);
	}
	public static void addSuccessPlayer(Player player){
		suc.addPlayer(player);
	}
	public static void addHunterPlayer(Player player){
		hunter.addPlayer(player);
	}
	public static void addAdmin_AUTO(Player p){
		if(p.isOp() && !joinTeam(p)) admin.addPlayer(p);
	}
	public static void removeTosoPlayer(Player player){
		toso.removePlayer(player);
		addAdmin_AUTO(player);
	}
	public static void removeCaughtPlayer(Player player){
		jail.removePlayer(player);
		addAdmin_AUTO(player);
	}
	public static void removeSuccessPlayer(Player player){
		suc.removePlayer(player);
		addAdmin_AUTO(player);
	}
	public static void removeHunterPlayer(Player player){
		hunter.removePlayer(player);
		addAdmin_AUTO(player);
	}
	public static void clearTosoPlayer(){
		clearPlayer(toso);
	}
	public static void clearCaughtPlayer(){
		clearPlayer(jail);
	}
	public static void clearSuccessPlayer(){
		clearPlayer(suc);
	}
	public static void clearHunterPlayer(){
		clearPlayer(hunter);
	}
	private static void clearPlayer(Team t){
		for(Player p : t.clearPlayers()){
			addAdmin_AUTO(p);
		}
	}
}
