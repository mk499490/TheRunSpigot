/*
 * @author keepoff07
 * @license GPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import com.github.keepoff07.hiyutosogame.listener.TLPlayerControl;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TosoGameAPI {

	public static boolean isAdmin(Player player) {
		return TosoScoreBoard.isAdminPlayer(player);
	}
	public static boolean isTosoPlayer(Player player) {
		return TosoScoreBoard.isTosoPlayer(player, false);
	}
	public static void addTosoPlayer(Player player) {
		player.getInventory().clear();
		removeArmor(player);
		TLPlayerControl.loginSendItems(player);
		player.setFoodLevel(20);
		setWalkSpeed(player, "TosoPlayer");
		TosoScoreBoard.addTosoPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void removeTosoPlayer(Player player) {
		TosoScoreBoard.removeTosoPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void clearTosoPlayer() {
		TosoScoreBoard.clearTosoPlayer();
		TosoTimer.setSideBar();
	}

	public static boolean isCaughtPlayer(Player player) {
		return TosoScoreBoard.isCaughtPlayer(player);
	}
	public static void addCaughtPlayer(Player player) {
		player.getInventory().clear();
		removeArmor(player);
		TLPlayerControl.loginSendItems(player);
		player.setFoodLevel(20);
		player.setWalkSpeed(0.2f);
		TosoScoreBoard.addCaughtPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void removeCaughtPlayer(Player player) {
		TosoScoreBoard.removeCaughtPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void clearCaughtPlayer() {
		TosoScoreBoard.clearCaughtPlayer();
		TosoTimer.setSideBar();
	}

	public static boolean isSuccessPlayer(Player player) {
		return TosoScoreBoard.isSuccessPlayer(player);
	}
	public static void addSuccessPlayer(Player player) {
		TosoScoreBoard.addSuccessPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void removeSuccessPlayer(Player player) {
		TosoScoreBoard.removeSuccessPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void clearSuccessPlayer() {
		TosoScoreBoard.clearSuccessPlayer();
		TosoTimer.setSideBar();
	}

	public static boolean isHunterPlayer(Player player) {
		return TosoScoreBoard.isHunterPlayer(player);
	}
	public static void addHunterPlayer(Player player) {
		player.getInventory().clear();
		setArmor(player);
		TLPlayerControl.loginSendItems(player);
		player.setFoodLevel(20);
		setWalkSpeed(player, "HunterPlayer");
		TosoScoreBoard.addHunterPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void removeHunterPlayer(Player player) {
		removeArmor(player);
		TosoScoreBoard.removeHunterPlayer(player);
		TosoTimer.setSideBar();
	}
	public static void clearHunterPlayer() {
		TosoScoreBoard.clearHunterPlayer();
		TosoTimer.setSideBar();
	}

	private static void setWalkSpeed(Player player, String path) {
		if(HIYU_TosoGame.read) {
			Config ps = HIYU_TosoGame.config;
			try{
				player.setWalkSpeed((float)ps.getDouble(path+".WalkSpeed"));
			}catch(ConfigNotFoundException | IllegalArgumentException ex){
				player.setWalkSpeed(0.2f);
			}
		}
	}

	private static String PathLJ = "JailPoint";
	private static String PathLR = "RevivalPoint";
	private static String PathLS = "SuccessPoint";
	private static String PathLH = "HunterGatherPoint";

	public static Location getJailLocation(){
		return getLocation(PathLJ);
	}
	public static boolean setJailLocation(Location location){
		return setLocation(location, PathLJ);
	}
	public static Location getRevivalLocation(){
		return getLocation(PathLR);
	}
	public static boolean setRevivalLocation(Location location){
		return setLocation(location, PathLR);
	}
	public static Location getSuccessLocation(){
		return getLocation(PathLS);
	}
	public static boolean setSuccessLocation(Location location){
		return setLocation(location, PathLS);
	}
	public static Location getGatherLocation(){
		return getLocation(PathLH);
	}
	public static boolean setGatherLocation(Location location){
		return setLocation(location, PathLH);
	}

	private static Location getLocation(String path) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.point;
			try {
				World w = Bukkit.getWorld(co.getString(path+".world"));
				if(w == null) return null;
				double x = co.getDouble(path+".x");
				double y = co.getDouble(path+".y");
				double z = co.getDouble(path+".z");
				float e = 0f;
				float f = 0f;
				try {
					e = (float)co.getDouble(path+".yaw");
					f = (float)co.getDouble(path+".pitch");
				}catch(ConfigNotFoundException e1){}
				return new Location(w,x,y,z,e,f);
			}catch(ConfigNotFoundException e){}
		} return null;
	}
	private static boolean setLocation(Location location, String path) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.point;
			co.set(path+".world", location.getWorld().getName());
			co.set(path+".x", location.getX());
			co.set(path+".y", location.getY());
			co.set(path+".z", location.getZ());
			co.set(path+".yaw", (double)location.getYaw());
			co.set(path+".pitch", (double)location.getPitch());
			return co.save();
		} return false;
	}

	public static Location getBox(int id) {
		return getBox("box"+id);
	}
	private static Location getBox(String path) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.box;
			try {
				World w = Bukkit.getWorld(co.getString(path+".world"));
				if(w == null) return null;
				int x = co.getInt(path+".x");
				int y = co.getInt(path+".y");
				int z = co.getInt(path+".z");
				return new Location(w,x,y,z);
			}catch(ConfigNotFoundException e){}
		} return null;
	}
	public static boolean setBox(Location location, int id) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.box;
			if(location != null){
				co.set("box"+id+".world", location.getWorld().getName());
				co.set("box"+id+".x", location.getBlockX());
				co.set("box"+id+".y", location.getBlockY());
				co.set("box"+id+".z", location.getBlockZ());
			} else {
				co.set("box"+id, null);
			}
			return co.save();
		} return false;
	}
	public static List<Location> getBoxs() {
		if(HIYU_TosoGame.read) {
			List<Location> boxs = new ArrayList<Location>();
			Config co = HIYU_TosoGame.box;
			for(String key : co.getKeys("")) {
				Location l = getBox(key);
				if(l != null) boxs.add(l);
			}
			return boxs;
		} return null;
	}
	public static void openOPBoxs(){
		if(HIYU_TosoGame.read) {
			for(Location l : getBoxs()){
				l.getBlock().setType(Material.AIR);
				l.getWorld().createExplosion(l.add(0.5d, 0.5, 0.5), 0);
			}
		}
	}

	@SuppressWarnings("deprecation")
	public static boolean sendItem(Player player, boolean force) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.items;
			if(!force) {
				try {
					force = co.getBoolean("SendItem.Enable");
				}catch(ConfigNotFoundException e1){}
			}
			if(!force) return true;
			try {
				int a = co.getInt("SendItem.speed");
				player.getInventory().addItem(new ItemStack(Material.FEATHER, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("SendItem.invisibility");
				player.getInventory().addItem(new ItemStack(Material.BONE, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("SendItem.blindness");
				player.getInventory().addItem(new ItemStack(Material.EGG, a));
			}catch(ConfigNotFoundException e1){}
			player.updateInventory();
			return true;
		} return false;
	}
	@SuppressWarnings("deprecation")
	public static boolean sendRevivalItem(Player player, boolean force) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.items;
			if(!force) {
				try {
					force = co.getBoolean("RevivalSendItem.Enable");
				}catch(ConfigNotFoundException e1){}
			}
			if(!force) return true;
			try {
				int a = co.getInt("RevivalSendItem.speed");
				player.getInventory().addItem(new ItemStack(Material.FEATHER, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("RevivalSendItem.invisibility");
				player.getInventory().addItem(new ItemStack(Material.BONE, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("RevivalSendItem.blindness");
				player.getInventory().addItem(new ItemStack(Material.EGG, a));
			}catch(ConfigNotFoundException e1){}
			player.updateInventory();
			return true;
		} return false;
	}
	@SuppressWarnings("deprecation")
	public static boolean sendMidwayItem(Player player, boolean force) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.items;
			if(!force) {
				try {
					force = co.getBoolean("MidwaySendItem.Enable");
				}catch(ConfigNotFoundException e1){}
			}
			if(!force) return true;
			try {
				int a = co.getInt("MidwaySendItem.speed");
				player.getInventory().addItem(new ItemStack(Material.FEATHER, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("MidwaySendItem.invisibility");
				player.getInventory().addItem(new ItemStack(Material.BONE, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("MidwaySendItem.blindness");
				player.getInventory().addItem(new ItemStack(Material.EGG, a));
			}catch(ConfigNotFoundException e1){}
			player.updateInventory();
			return true;
		} return false;
	}
	@SuppressWarnings("deprecation")
	public static boolean sendCommandItem(Player player, boolean force) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.items;
			if(!force) {
				try {
					force = co.getBoolean("CommandSendItem.Enable");
				}catch(ConfigNotFoundException e1){}
			}
			if(!force) return true;
			try {
				int a = co.getInt("CommandSendItem.speed");
				player.getInventory().addItem(new ItemStack(Material.FEATHER, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("CommandSendItem.invisibility");
				player.getInventory().addItem(new ItemStack(Material.BONE, a));
			}catch(ConfigNotFoundException e1){}
			try {
				int a = co.getInt("CommandSendItem.blindness");
				player.getInventory().addItem(new ItemStack(Material.EGG, a));
			}catch(ConfigNotFoundException e1){}
			player.updateInventory();
			return true;
		} return false;
	}
	@SuppressWarnings("deprecation")
	public static void setArmor(Player player){
		PlayerInventory inv = player.getInventory();
		inv.setHelmet(new ItemStack(Material.DIAMOND_HELMET));
		inv.setChestplate(new ItemStack(Material.DIAMOND_CHESTPLATE));
		inv.setLeggings(new ItemStack(Material.DIAMOND_LEGGINGS));
		inv.setBoots(new ItemStack(Material.DIAMOND_BOOTS));
		player.updateInventory();
	}
	@SuppressWarnings("deprecation")
	public static void removeArmor(Player player){
		PlayerInventory inv = player.getInventory();
		inv.setHelmet(new ItemStack(Material.AIR));
		inv.setChestplate(new ItemStack(Material.AIR));
		inv.setLeggings(new ItemStack(Material.AIR));
		inv.setBoots(new ItemStack(Material.AIR));
		player.updateInventory();
	}
	//#Request8
	public static boolean playerRevival(Player player) {
		if(HIYU_TosoGame.read) {
			Location l = getRevivalLocation();
			if(l != null){
				addTosoPlayer(player);
				sendRevivalItem(player, false);
				player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 200, 0));
				player.teleport(l);
				return true;
			}
		} return false;
	}
	public static PotionEffect getPotionEffect(PotionEffectType type, String path) {
		return getPotionEffect(type, HIYU_TosoGame.items, path);
	}
	public static PotionEffect getPotionEffect(PotionEffectType type, Config config, String path) {
		if(HIYU_TosoGame.read) {
			int lv = 0;
			int du = 100;
			boolean am = false;
			path = path+"."+getEffectPath(type);
			if(!config.contains(path)) return null;
			try {
				lv = config.getInt(path+".Lv") - 1;
			}catch(ConfigNotFoundException e1){}
			try {
				du = config.getInt(path+".Duration");
			}catch(ConfigNotFoundException e1){}
			try {
				am = config.getBoolean(path+".Ambient");
			}catch(ConfigNotFoundException e1){}
			return new PotionEffect(type, du, lv, am);
		} return null;
	}
	private static String getEffectPath(PotionEffectType type){
		if(type.equals(PotionEffectType.SPEED)) return "Speed";
		else if(type.equals(PotionEffectType.INVISIBILITY)) return "Invisibility";
		else if(type.equals(PotionEffectType.BLINDNESS)) return "Blindness";
		else if(type.equals(PotionEffectType.DAMAGE_RESISTANCE)) return "Resistance";
		else if(type.equals(PotionEffectType.SLOW)) return "Slowness";
		else if(type.equals(PotionEffectType.CONFUSION)) return "Nausea";
		else if(type.equals(PotionEffectType.HUNGER)) return "Hunger";
		return "Speed";
	}
}
