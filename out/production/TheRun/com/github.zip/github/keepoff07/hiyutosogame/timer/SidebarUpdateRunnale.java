/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.timer;

import org.bukkit.scheduler.BukkitRunnable;

public class SidebarUpdateRunnale extends BukkitRunnable{
	@Override
	public void run() {
		TosoTimer.setSideBar();
	}
}
