/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.command.CommandSender;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;

public class TCHelp {
	static String pex = "";
	static String suf = " §a§l■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■ ■";
	static {
		pex = " §a§l■ ■ ■ ■ ■ §6§lHIYU§f_§4§lTosoGame §f"
			+HIYU_TosoGame.plugin.getDescription().getVersion()
			+" §a§l■ ■ ■ ■ ■";
	}
	public static boolean doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 0) {
			main(sender);
			return true;
		}
		else if(args.length == 1) {
			if(args[0].equalsIgnoreCase("toso")) {
				toso(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("hunter")) {
				hunter(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("timer")) {
				timer(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("point")) {
				point(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("config")) {
				config(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("mission")) {
				mission(sender);
				return true;
			} else if(args[0].equalsIgnoreCase("book")) {
				book(sender);
				return true;
			}
		} return false;
	}
	public static void main(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §4§l/toso start §f- §9ゲーム開始");
		sender.sendMessage(" §4§l/toso stop §f- §9ゲーム一時停止");
		sender.sendMessage(" §4§l/toso reset §f- §9ゲームリセット");
		sender.sendMessage(" §6/toso toso §f- §9逃走者選択設定");
		sender.sendMessage(" §6/toso hunter §f- §9ハンター選択設定");
		sender.sendMessage(" §6/toso mission §f- §9ミッション設定");
		sender.sendMessage(" §6/toso timer §f- §9タイマー設定");
		sender.sendMessage(" §6/toso point §f- §9ポイント設定");
		sender.sendMessage(" §6/toso config §f- §9Config設定");
		sender.sendMessage(suf);
	}
	public static void toso(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso t add <PLAYER> §f- §9逃走者追加");
		sender.sendMessage(" §6/toso t remove <PLAYER> §f- §9逃走者消去");
		sender.sendMessage(" §6/toso t clear <PLAYER> §f- §9逃走者情報初期化");
		sender.sendMessage(suf);
	}
	public static void hunter(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso h add <PLAYER> §f- §9ハンター追加");
		sender.sendMessage(" §6/toso h remove <PLAYER> §f- §9ハンター消去");
		sender.sendMessage(" §6/toso h clear <PLAYER> §f- §9ハンター情報初期化");
		sender.sendMessage(" §6/toso h random §f- §9ハンターのランダム追加");
		sender.sendMessage(suf);
	}
	public static void timer(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso timer set <SECOND> §f- §9ゲーム時間設定");
		sender.sendMessage(" §6/toso timer countdown <SECOND>");
		sender.sendMessage(" §f- §9ゲーム開始カウントダウン時間設定");
		sender.sendMessage(" §6/toso timer end §f- §9タイマー強制終了");
		sender.sendMessage(suf);
	}
	public static void point(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso p set <jail|rev|suc|gath> §f- §9TP場所設定");
		sender.sendMessage(" §6/toso tp <jail|rev|suc|gath> §f- §9設定場所TP");
		sender.sendMessage(" §6/toso box add <NUMBER> §f- §9OPBox追加");
		sender.sendMessage(" §6/toso box remove <NUMBER> §f- §9OPBox削除");
		sender.sendMessage(suf);
	}
	public static void mission(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso mission success §f- §9逃走成功ミッション");
		sender.sendMessage(" §6/toso mission area §f- §9エリア拡張ミッション");
		sender.sendMessage(" §6/toso mission blocking §f- §9ゾンビハンター阻止ミッション");
		sender.sendMessage(" §6/toso mission zombie add <NUMBER> §f- §9ゾンビハンタースポーン追加");
		sender.sendMessage(" §6/toso mission zombie remove <NUMBER> §f- §9ゾンビハンタースポーン削除");
		sender.sendMessage(" §6/toso mission blocking <TIME> §f- §9ゾンビハンター開放時間");
		sender.sendMessage(" §6/toso mission surrender §f- §9自首ミッション");
		sender.sendMessage(" §6/toso book §f- §9本配布");
		sender.sendMessage(suf);
	}
	public static void book(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso book send §f- §9本配布&ミッション通知");
		sender.sendMessage(suf);
	}
	public static void config(CommandSender sender) {
		sender.sendMessage(pex);
		sender.sendMessage(" §6/toso config edit <FileName> <Path> <ObjectType> [Value]");
		sender.sendMessage(" §f- §9Config操作");
		sender.sendMessage(" §4#ObjectType: §6String§f|§6Int§f|§6Double§f|§6Boolean");
		sender.sendMessage(suf);
	}
}
