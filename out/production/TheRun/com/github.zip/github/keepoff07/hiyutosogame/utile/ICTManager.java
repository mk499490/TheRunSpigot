package com.github.keepoff07.hiyutosogame.utile;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class ICTManager {

	/*
	 * 羽:0 骨:1 卵:2
	 */
	private static int[] CT = {15, 15, 6};
	private static Material[] CTM = {Material.FEATHER, Material.BONE, Material.EGG};
	static {
		if(HIYU_TosoGame.read) {
			try {
				CT[0] = HIYU_TosoGame.items.getInt("ItemSetting.Speed.CoolTime");
			}catch(ConfigNotFoundException e){}
			try {
				CT[1] = HIYU_TosoGame.items.getInt("ItemSetting.Invisibility.CoolTime");
			}catch(ConfigNotFoundException e){}
			try {
				CT[2] = HIYU_TosoGame.items.getInt("ItemSetting.Blindness.CoolTime");
			}catch(ConfigNotFoundException e){}
		}
	}
	static Map<UUID, ItemCoolTime[]> manager = new HashMap<UUID, ItemCoolTime[]>();
	public static void setTime(Player p, int index) {
		UUID uuid = p.getUniqueId();
		ItemCoolTime[] ct;
		if(manager.containsKey(uuid)) {
			ct = manager.get(uuid);
		} else {
			ct = new ItemCoolTime[3];
		}
		ItemCoolTime ict = new ItemCoolTime(p, CTM[index], CT[index]);
		ict.runTaskTimer(HIYU_TosoGame.plugin, 0, 1);
		ct[index] = ict;
		manager.put(uuid, ct);
	}
	public static void getTime(Player p, int index) {
		if(index != -1) {
			UUID uuid = p.getUniqueId();
			if(manager.containsKey(uuid)) {
				ItemCoolTime ict = manager.get(uuid)[index];
				if(ict != null) {
					int t = ict.getTime();
					p.setLevel(t);
					p.setExp((float)t/(float)CT[index]);
					return;
				}
			}
		}
		p.setLevel(0);
		p.setExp(0f);
		return;
	}
	public static class ItemCoolTime extends BukkitRunnable {
		Player player;
		Material mate;
		int max = 0;
		int time = 0;
		public ItemCoolTime(Player player, Material mate, int time) {
			this.player = player;
			this.mate = mate;
			this.max = time*20;
			this.time = time*20;
		}
		@Override
		public void run() {
			if(this.time == 0) {
				if(player.isOnline() && player.getItemInHand().getType().equals(mate)) {
					player.setLevel(0);
					player.setExp(0f);
				}
				this.cancel();
			} else {
				if(player.isOnline() && player.getItemInHand().getType().equals(mate)) {
					player.setLevel(time/20);
					player.setExp((float)time/(float)max);
				}
				time--;
			}
		}
		public int getTime() {
			return time;
		}
	}
}
