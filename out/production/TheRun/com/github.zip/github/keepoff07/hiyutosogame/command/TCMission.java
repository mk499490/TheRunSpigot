/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.listener.TLMission;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TCMission {

	static String pex = TosoCommands.pex;
	static MItem success_block;
	static MItem success_button;
	public static MItem area_chest;
	public static List<MItem> area_content;
	static MItem blocking_block;
	static MItem blocking_button;
	static MItem surrender_block;
	static MItem surrender_button;
	static {
		success_block = new MItem(Material.EMERALD_BLOCK, 1, (short)0, "§a逃走成功装置 §4A§r", null);
		success_button = new MItem(Material.STONE_BUTTON, 1, (short)0, "§a逃走成功装置 §1B§r", null);
		area_chest = new MItem(Material.CHEST, 1, (short)0, "§6拡張装置保管庫§r", null);
		TCMission.loadMissionConfig();
		blocking_block = new MItem(Material.DIAMOND_BLOCK, 1, (short)0, "§9ハンター開放停止装置 §4A§r", null);
		blocking_button = new MItem(Material.STONE_BUTTON, 1, (short)0, "§9ハンター開放停止装置 §1B§r", null);
		surrender_block = new MItem(Material.IRON_BLOCK, 1, (short)0, "§7自首装置 §4A§r", null);
		surrender_button = new MItem(Material.STONE_BUTTON, 1, (short)0, "§7自首装置 §1B§r", null);
	}

	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("success")) {
			if(sender instanceof Player) {
				Player player = (Player)sender;
				player.getInventory().addItem(success_block.getItemStack(), success_button.getItemStack());
			}
			return;
		}
		else if(args[1].equalsIgnoreCase("area")) {
			if(sender instanceof Player) {
				Player player = (Player)sender;
				player.getInventory().addItem(area_chest.getItemStack());
			}
			return;
		}
		else if(args[1].equalsIgnoreCase("blocking")) {
			if(args.length == 3) {
				int min = 0;
				int sec = 0;
				try {
					String[] args2 = args[2].split(":");
					min = Integer.parseInt(args2[0]);
					sec = Integer.parseInt(args2[1]);
				} catch(NumberFormatException | IndexOutOfBoundsException ex) {
					sender.sendMessage(" §c/"+label+" mission blocking <TIME>");
					return;
				}
				TLMission.startBlockingTimer(min*60+sec);
				return;
			} else {
				if(sender instanceof Player) {
					Player player = (Player)sender;
					player.getInventory().addItem(blocking_block.getItemStack(), blocking_button.getItemStack());
				}
			}
			return;
		}
		else if(args[1].equalsIgnoreCase("zombie")) {
			if(args.length == 4 && sender instanceof Player) {
				Player player = (Player)sender;
				int num = 0;
				try {
					num = Integer.parseInt(args[3]);
				} catch(NumberFormatException e) {
					senderror(sender, label);
					return;
				}
				if(args[2].equalsIgnoreCase("add")) {
					TLMission.addBox(num, player.getLocation());
					player.sendMessage(pex+"§eゾンビハンタースポーン["+num+"]§aを追加しました。");
					return;
				} else if(args[2].equalsIgnoreCase("remove")) {
					Location box = TLMission.getBox(num);
					if(box != null) {
						TLMission.addBox(num, null);
						player.sendMessage(pex+"§eゾンビハンタースポーン["+num+"]§aを削除しました。");
					} else {
						player.sendMessage(pex+"§eゾンビハンタースポーン["+num+"]§aは未設定です。");
					}
					return;
				}
			}
			senderror(sender, label);
			return;
		}
		else if(args[1].equalsIgnoreCase("surrender")) {
			if(sender instanceof Player) {
				Player player = (Player)sender;
				player.getInventory().addItem(surrender_block.getItemStack(), surrender_button.getItemStack());
			}
			return;
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" mission <success|area|blocking|surrender>");
		sender.sendMessage("/"+label+" mission blocking <time>");
		sender.sendMessage("/"+label+" mission zombie <add|remove> <number>");
	}
	public static void loadMissionConfig() {
		area_content = new ArrayList<MItem>();
		Config config = HIYU_TosoGame.mission;
		String path = "Missions.Area.ChestItems";
		if(config.contains(path)) {
			for(int i = 0; i < 27; i++) {
				MItem item = MItem.createMItem(config, path+".slot"+i);
				area_content.add(item);
			}
		}
	}
	public static enum MIType {
		SUCCESS_BLOCK,
		SUCCESS_BUTTON,
		AREA_CHEST,
		BLOCKING_BLOCK,
		BLOCKING_BUTTON,
		SURRENDER_BLOCK,
		SURRENDER_BUTTON,
		NOT;
		public static MIType getType(ItemStack item) {
			if(TCMission.success_block.equals(item)) return MIType.SUCCESS_BLOCK;
			else if(TCMission.success_button.equals(item)) return MIType.SUCCESS_BUTTON;
			else if(TCMission.area_chest.equals(item)) return MIType.AREA_CHEST;
			else if(TCMission.blocking_block.equals(item)) return MIType.BLOCKING_BLOCK;
			else if(TCMission.blocking_button.equals(item)) return MIType.BLOCKING_BUTTON;
			else if(TCMission.surrender_block.equals(item)) return MIType.SURRENDER_BLOCK;
			else if(TCMission.surrender_button.equals(item)) return MIType.SURRENDER_BUTTON;
			return MIType.NOT;
		}
	}
	public static class MItem {
		MIType type;
		ItemStack item;
		Material material;
		short damage;
		String name;
		List<String> lore;
		public MItem(Material material, int amount, short damage, String name, List<String> lore) {
			this.material = material;
			this.damage = damage;
			this.name = name;
			this.lore = lore;
			ItemStack item = new ItemStack(material, amount, damage);
			if(name != null || lore != null) {
				ItemMeta meta = item.getItemMeta();
				if(name != null) meta.setDisplayName(name);
				if(lore != null) meta.setLore(lore);
				item.setItemMeta(meta);
			}
			this.item = item;
		}
		public static MItem createMItem(Config config, String path) {
			try {
				String str$id = config.getString(path+".ID");
				Material id = Material.getMaterial(str$id);
				if(id == null) {
					HIYU_TosoGame.plugin.getLogger().warning("'"+path+".ID' is not found");
					return null;
				}
				int amount = 1;
				short damage = 0;
				String name = null;
				List<String> lore = null;
				try {
					amount = config.getInt(path+".Amount");
					if(amount <= 0) amount = 1;
					else if(amount > 64) amount = 64;
				} catch(ConfigNotFoundException ex) {}
				try {
					damage = (short)config.getInt(path+".Damage");
				} catch(ConfigNotFoundException ex) {}
				try {
					name = config.getString(path+".Name");
				} catch(ConfigNotFoundException ex) {}
				try {
					lore = config.getStringList(path+".Lore");
				} catch(ConfigNotFoundException ex) {}
				return new MItem(id, amount, damage, name, lore);
			} catch(ConfigNotFoundException ex) {
				return null;
			}
		}
		public ItemStack getItemStack() {
			return this.item;
		}
		public String getName() {
			return this.name;
		}
		public boolean equals(ItemStack item) {
			if(item.getType().equals(this.material) && item.getDurability() == this.damage) {
				if(this.name != null || this.lore != null) {
					if(item.hasItemMeta()) {
						ItemMeta meta = item.getItemMeta();
						if(name != null && !meta.getDisplayName().equals(this.name)) return false;
						if(lore != null && !meta.getLore().equals(this.lore)) return false;
						return true;
					} else return false;
				} else return true;
			} else return false;
		}
	}
}
