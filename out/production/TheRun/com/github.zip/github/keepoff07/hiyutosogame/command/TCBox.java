/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.github.keepoff07.hiyutosogame.TosoGameAPI;

public class TCBox {

	static String pex = TosoCommands.pex;
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("add")) {
			if(args.length == 3 && sender instanceof Player) {
				try{
					Location l = ((Player)sender).getLocation();
					int i = Integer.parseInt(args[2]);
					TosoGameAPI.setBox(l, i);
					sender.sendMessage(pex+"§aOPBox["+i+"]を設定しました。");
					return;
				}catch(NumberFormatException e){
					sender.sendMessage(pex+"§c入力した値に問題があります");
					return;
				}
			}
		}
		else if(args[1].equalsIgnoreCase("remove")) {
			if(args.length == 3) {
				try{
					int i = Integer.parseInt(args[2]);
					if(TosoGameAPI.getBox(i) != null){
						TosoGameAPI.setBox(null, i);
						sender.sendMessage(pex+"§aOPBox["+i+"]を削除しました。");
					} else {
						sender.sendMessage(pex+"§aOPBox["+i+"]は未設定です。");
					}
					return;
				}catch(NumberFormatException e){
					sender.sendMessage(pex+"§c入力した値に問題があります");
					return;
				}
			}
		}
		else if(args[1].equalsIgnoreCase("open")) {
			TosoGameAPI.openOPBoxs();
			return;
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" box add <id>");
		sender.sendMessage("/"+label+" box remove <id>");
	}
}
