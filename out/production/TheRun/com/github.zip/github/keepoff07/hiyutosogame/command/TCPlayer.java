/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;

public class TCPlayer {

	static String pex = TosoCommands.pex;
	@SuppressWarnings("deprecation")
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("add")) {
			if(args.length == 3) {
				Player p = Bukkit.getPlayerExact(args[2]);
				if(p == null) {
					sender.sendMessage(pex+"§c指定されたプレイヤーが見つかりません");
				} else {
					if(TosoScoreBoard.isTosoPlayer(p, true)) {
						sender.sendMessage(pex+"§c指定されたプレイヤーは既に逃走者です");
					} else {
						TosoGameAPI.addTosoPlayer(p);
						TosoGameAPI.sendCommandItem(p, false);
						sender.sendMessage(pex+"§e"+p.getName()+"§bを逃走者に追加しました。");
					}
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("remove")) {
			if(args.length == 3) {
				Player p = Bukkit.getPlayerExact(args[2]);
				if(p == null) {
					sender.sendMessage(pex+"§c指定されたプレイヤーが見つかりません");
				} else {
					if(TosoGameAPI.isTosoPlayer(p)) {
						if(TosoGameAPI.isCaughtPlayer(p)) {
							TosoGameAPI.removeCaughtPlayer(p);
							sender.sendMessage(pex+"§e"+p.getName()+"§bを確保者から削除しました。");
						} else if(TosoGameAPI.isSuccessPlayer(p)) {
							TosoGameAPI.removeSuccessPlayer(p);
							sender.sendMessage(pex+"§e"+p.getName()+"§bを逃走成功者から削除しました。");
						} else {
							TosoGameAPI.removeTosoPlayer(p);
							sender.sendMessage(pex+"§e"+p.getName()+"§bを逃走者から削除しました。");
						}
					} else {
						sender.sendMessage(pex+"§c指定されたプレイヤーは既に逃走者ではありません。");
					}
				}
				return;
			}
		}
		else if(args[1].equalsIgnoreCase("clear")) {
			TosoGameAPI.clearTosoPlayer();
			sender.sendMessage(pex+"§a逃走者の情報を初期化しました。");
			return;
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" t add <Player>");
		sender.sendMessage("/"+label+" t remove <Player>");
		sender.sendMessage("/"+label+" t clear");
	}
}
