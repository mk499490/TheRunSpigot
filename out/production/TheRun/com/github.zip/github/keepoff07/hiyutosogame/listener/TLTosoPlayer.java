/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.ICTManager;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.Utility;

public class TLTosoPlayer implements Listener{

	//#Request6
	@EventHandler
	public void onPlayerRevival(PlayerInteractEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(e.getAction().equals(Action.PHYSICAL)){
				Block b = e.getClickedBlock();
				Block u = b.getRelative(BlockFace.DOWN);
				if(b.getType().equals(Material.IRON_PLATE) && u.getType().equals(Material.IRON_BLOCK) &&
						TosoGameAPI.isCaughtPlayer(p)){
					if(TosoGameAPI.playerRevival(p)){
						Utility.sendAnnounce("TosoPlayer.Revival", p);
					}
				}
			}
		}
	}
	//#Request6
	@EventHandler
	public void onPlayerItemUse(PlayerInteractEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(e.getAction().equals(Action.RIGHT_CLICK_AIR)|e.getAction().equals(Action.RIGHT_CLICK_BLOCK)){
				ItemStack item = p.getItemInHand();
				if(TosoTimer.onGame && TosoGameAPI.isTosoPlayer(p) & !TosoGameAPI.isCaughtPlayer(p)){
					if(item.getType().equals(Material.BONE)
							&& !p.hasPotionEffect(PotionEffectType.INVISIBILITY)){
						e.setCancelled(true);
						if(p.getExp() > 0f) return;
						PotionEffect effect = TosoGameAPI.getPotionEffect(PotionEffectType.INVISIBILITY,"ItemSetting");
						if(effect != null) p.addPotionEffect(effect);
						Utility.sendAnnounce("TosoPlayer.UseItem_Invisibility", p);
						costItem(p, item);
						ICTManager.setTime(p, 1);
						TLHunterZombie.breakTarget(p);
					}
					if(item.getType().equals(Material.FEATHER)
							&& !p.hasPotionEffect(PotionEffectType.SPEED)){
						e.setCancelled(true);
						if(p.getExp() > 0f) return;
						PotionEffect effect = TosoGameAPI.getPotionEffect(PotionEffectType.SPEED,"ItemSetting");
						if(effect != null) p.addPotionEffect(effect);
						Utility.sendAnnounce("TosoPlayer.UseItem_Speed", p);
						costItem(p, item);
						ICTManager.setTime(p, 0);
					}
					if(item.getType().equals(Material.EGG)) {
						if(p.getExp() > 0f) {
							e.setCancelled(true);
							return;
						}
						ICTManager.setTime(p, 2);
						Utility.sendAnnounce("TosoPlayer.UseItem_Blindness", p);
					}
					if(item.getType().equals(Material.SNOW_BALL)) {
						Utility.sendAnnounce("TosoPlayer.UseItem_Snowball", p);
					}
				}
			}
		}
	}
	private void costItem(Player p,ItemStack item){
		int a = item.getAmount() - 1;
		if(a == 0) p.setItemInHand(null);
		else {
			item.setAmount(a);
			p.setItemInHand(item);
		}
	}
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			if(!(TosoGameAPI.isAdmin(p)|TosoGameAPI.isCaughtPlayer(p))){
				TosoGameAPI.addTosoPlayer(p);
				TosoGameAPI.sendMidwayItem(p, false);
			} else if(TosoGameAPI.isAdmin(p) & TosoGameAPI.isHunterPlayer(p)){
				TosoGameAPI.addTosoPlayer(p);
				TosoGameAPI.sendMidwayItem(p, false);
			}
			TosoScoreBoard.addAdmin_AUTO(p);
		}
	}
	@EventHandler
	public void onPlayerItemHeld(PlayerItemHeldEvent e){
		if(HIYU_TosoGame.read){
			Player p = e.getPlayer();
			ItemStack item = p.getInventory().getItem(e.getNewSlot());
			if(item != null) {
				switch(item.getType()) {
				case FEATHER:
					ICTManager.getTime(p, 0);
					break;
				case BONE:
					ICTManager.getTime(p, 1);
					break;
				case EGG:
					ICTManager.getTime(p, 2);
					break;
				default:
					ICTManager.getTime(p, -1);
					break;
				}
			} else {
				ICTManager.getTime(p, -1);
				return;
			}
		}
	}
}
