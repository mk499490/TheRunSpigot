/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.timer;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.listener.TLMission;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TosoTimer {

	public static int gametime = 120;
	public static int countdown = 10;
	static BukkitTask timer = null;

	public static int subA = 0;
	public static int subB = 0;

	public static boolean onGame = false;
	public static boolean onGame2 = false;

	private static DisplayData[] data;

	public static boolean startTimer(){
		if(timer == null){
			timer = new TosoRunnale(countdown, gametime).runTaskTimer(HIYU_TosoGame.plugin, 0L, 20L);
			onGame2 = true;
			return true;
		}
		return false;
	}
	public static boolean endTimer(){
		if(timer != null){
			timerEndAction();
			timer.cancel();
			timer = null;
			setSideBar(0,0);
			onGame = false;
			onGame2 = false;
			TLMission.removeZombieHunter();
			return true;
		}
		return false;
	}
	public static void timerStartAction(){
		Location l = TosoGameAPI.getRevivalLocation();
		if(l != null){
			for(Player p : Utility.getOnlinePlayers()){
				if(TosoGameAPI.isTosoPlayer(p)){
					TosoGameAPI.sendItem(p, false);
					p.teleport(l);
				}
			}
		}
		TosoGameAPI.openOPBoxs();
	}
	public static void timerEndAction(){

	}
	public static void sendMoney(){
		try {
			double mo = HIYU_TosoGame.config.getDouble("iConomy");
			for(Player p : Utility.getOnlinePlayers()) {
				if(TosoGameAPI.isTosoPlayer(p) & !TosoGameAPI.isCaughtPlayer(p)){
					HIYU_TosoGame.economy.depositPlayer(p, mo);
				}
			}
		}catch(ConfigNotFoundException ex){}

	}

	public static void setSideBar(int cd, int gm){
		subA = cd;
		subB = gm;
		setSideBar();
	}
	public static void setSideBar(){
		loadSidebarConfig();
		int[] r = getRest();
		for(Player p : Utility.getOnlinePlayers()) {
			Scoreboard scoreboard = Bukkit.getServer().getScoreboardManager().getNewScoreboard();
			if(scoreboard.getObjective("HIYUTosoGameRest") != null)
				scoreboard.getObjective("HIYUTosoGameRest").unregister();
			Objective rest = scoreboard.registerNewObjective("HIYUTosoGameRest", "");

			Scoreboard sb_main = Bukkit.getServer().getScoreboardManager().getMainScoreboard();
			for(Team tm : sb_main.getTeams()) {
				Team tn = scoreboard.registerNewTeam(tm.getName());
				tn.setPrefix(tm.getPrefix());
				tn.setSuffix(tm.getSuffix());
				tn.setDisplayName(tm.getDisplayName());
				tn.setAllowFriendlyFire(false);
				tn.setCanSeeFriendlyInvisibles(true);
				for(OfflinePlayer om : tm.getPlayers()) {
					tn.addPlayer(om);
				}
			}

			rest.setDisplayName(getString("Title"));
			rest.setDisplaySlot(DisplaySlot.SIDEBAR);
			if(subB > 0){
				if(subA > 0){
					if(data[11].enable && data[11].score != 0) {
						rest.getScore(format(subA, data[11].display)).setScore(data[11].score);
					}
				} else {
					if(data[10].enable && data[10].score != 0) {
						rest.getScore(format(subB, data[10].display)).setScore(data[10].score);
					}
				}
			} else {
				if(data[12].enable && data[12].score != 0) {
					rest.getScore(data[12].display).setScore(data[12].score);
				}
			}

			for(int i = 0; i < 5; i++) {
				if(data[i].enable && data[i].score != 0) {
					String d = data[i].display.replace("%s", String.valueOf(r[i]));
					rest.getScore(d).setScore(data[i].score);
				}
				int a = i + 5;
				if(data[a].enable && data[a].score != 0) {
					String d = data[a].display.replace("%s", String.valueOf(r[i]));
					rest.getScore(d).setScore(data[a].score);
				}
			}
			//Money
			if(data[13].enable && data[13].score != 0) {
				String d = data[13].display.replace("%s", String.valueOf(HIYU_TosoGame.economy.getBalance(p)));
				rest.getScore(d).setScore(data[13].score);
			}
			//MoneyDisplay & TimerDisplay
			for(int i = 14; i < 16; i++) {
				if(data[i].enable && data[i].score != 0) {
					rest.getScore(data[i].display).setScore(data[i].score);
				}
			}
			p.setScoreboard(scoreboard);
		}

	}
	private static int[] getRest(){
		int[] rest = {0,0,0,0,0};//Admin-Player-Caught-Succes-Hunter
		for(Player p : Utility.getOnlinePlayers()){
			if(TosoGameAPI.isHunterPlayer(p)){
				rest[4]++;
			} else if(TosoGameAPI.isSuccessPlayer(p)){
				rest[3]++;
			} else if(TosoGameAPI.isCaughtPlayer(p)){
				rest[2]++;
			} else if(TosoGameAPI.isTosoPlayer(p)){
				rest[1]++;
			} else if(TosoGameAPI.isAdmin(p)){
				rest[0]++;
			}
		}
		return rest;
	}
	public static void loadSidebarConfig() {
		data = new DisplayData[16];
		data[0] = new DisplayData("AdminPlayer");
		data[1] = new DisplayData("TosoPlayer");
		data[2] = new DisplayData("CaughtPlayer");
		data[3] = new DisplayData("SuccessPlayer");
		data[4] = new DisplayData("HunterPlayer");
		data[5] = new DisplayData("AdminPlayerCount");
		data[6] = new DisplayData("TosoPlayerCount");
		data[7] = new DisplayData("CaughtPlayerCount");
		data[8] = new DisplayData("SuccessPlayerCount");
		data[9] = new DisplayData("HunterPlayerCount");
		data[10] = new DisplayData("Timer");
		data[11] = new DisplayData("CountDown");
		data[12] = new DisplayData("End");
		data[13] = new DisplayData("Money");
		data[14] = new DisplayData("TimerDisplay");
		data[15] = new DisplayData("MoneyDisplay");
	}
	private static String format(int time, String arg){
		int m = 0;
		int s = time;
		if(s >= 60){
			m = s / 60;
			s = s - m*60;
		}
		String sm = String.valueOf(m);
		String ss = String.valueOf(s);
		if(m <= 9) sm = "0"+sm;
		if(s <= 9) ss = "0"+ss;
		String i = arg.replace("%m", sm).replace("%s", ss);
		if(i.length() < 17) return i;
		else return "§c"+sm+":"+ss;
	}
	public static String getString(String path){
		if(HIYU_TosoGame.read){
			try {
				return HIYU_TosoGame.sidebar.getString(path);
			}catch(ConfigNotFoundException e){}
		} return path;
	}
	public static class DisplayData {
		boolean enable = false;
		String display = "";
		int score = 0;

		public DisplayData(String path) {
			if(HIYU_TosoGame.read){
				try {
					display = HIYU_TosoGame.sidebar.getString(path+".Display");
					score = HIYU_TosoGame.sidebar.getInt(path+".Score");
					enable = true;
				}catch(ConfigNotFoundException e){}
			}
		}
	}
}
