/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.command.TosoCommands;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;
import com.github.keepoff07.hiyutosogame.command.TCMission;
import com.github.keepoff07.hiyutosogame.command.TCMission.MIType;
import com.github.keepoff07.hiyutosogame.command.TCMission.MItem;

public class TLMission implements Listener{

	private static Block SUCCESS_BLOCK = null;
	private static Block SUCCESS_BUTTON = null;
	private static Block AREA_CHEST = null;
	private static Block BLOCKING_BLOCK = null;
	private static Block BLOCKING_BUTTON = null;
	private static Block SURRENDER_BLOCK = null;
	private static Block SURRENDER_BUTTON = null;
	private static Map<String, UUID> SURRENDER_PLAYERS = new HashMap<String, UUID>();
	public static boolean BLOCKING_FLAG = false;
	public static int BLOCKING_TIME = -1;
	//static BukkitRunnable BLOCKING_TASK;

	@EventHandler
	public void onBlockPlace(BlockPlaceEvent event) {
		if(HIYU_TosoGame.read){
			Player player = event.getPlayer();
			if(TosoGameAPI.isAdmin(player)) {
				MIType type = MIType.getType(player.getItemInHand());
				Block block = event.getBlock();
				switch(type) {
				case SUCCESS_BLOCK: {
					if(SUCCESS_BLOCK == null) {
						SUCCESS_BLOCK = block;
						player.sendMessage(TosoCommands.pex+"§e[§a逃走成功装置§4A§e]を設置しました");
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§a逃走成功装置§4A§c]は既に設置されています");
					}
					return;
				}
				case SUCCESS_BUTTON: {
					if(SUCCESS_BLOCK != null) {
						if(onLocation(SUCCESS_BLOCK, event.getBlockAgainst().getLocation())) {
							if(SUCCESS_BUTTON == null) {
								SUCCESS_BUTTON = block;
								player.sendMessage(TosoCommands.pex+"§e[§a逃走成功装置§1B§e]を設置しました");
							} else {
								event.setCancelled(true);
								player.sendMessage(TosoCommands.pex+"§c[§a逃走成功装置§1B§c]は既に設置されています");
							}
						} else {
							event.setCancelled(true);
							player.sendMessage(TosoCommands.pex+"§c[§a逃走成功装置§4A§c]に設置してください");
						}
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§a逃走成功装置§4A§c]が未設置です");
					}
					return;
				}
				case AREA_CHEST: {
					if(AREA_CHEST == null) {
						Chest chest = (Chest)block.getState();
						Inventory inv = chest.getBlockInventory();
						List<MItem> content = TCMission.area_content;
						for(int i = 0; i < 27; i++) {
							MItem item = content.get(i);
							if(item != null) inv.setItem(i, item.getItemStack());
						}
						chest.update();
						AREA_CHEST = block;
						player.sendMessage(TosoCommands.pex+"§e[§6拡張装置保管庫§e]を設置しました");
						return;
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§6拡張装置保管庫§c]は既に設置されています");
					}
					return;
				}
				case BLOCKING_BLOCK: {
					if(BLOCKING_BLOCK == null) {
						BLOCKING_BLOCK = block;
						player.sendMessage(TosoCommands.pex+"§e[§9ハンター開放停止装置§4A§e]を設置しました");
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§9ハンター開放停止装置§4A§c]は既に設置されています");
					}
					return;
				}
				case BLOCKING_BUTTON: {
					if(BLOCKING_BLOCK != null) {
						if(onLocation(BLOCKING_BLOCK, event.getBlockAgainst().getLocation())) {
							if(BLOCKING_BUTTON == null) {
								BLOCKING_BUTTON = block;
								player.sendMessage(TosoCommands.pex+"§e[§9ハンター開放停止装置§1B§e]を設置しました");
							} else {
								event.setCancelled(true);
								player.sendMessage(TosoCommands.pex+"§c[§9ハンター開放停止装置§1B§c]は既に設置されています");
							}
						} else {
							event.setCancelled(true);
							player.sendMessage(TosoCommands.pex+"§c[§9ハンター開放停止装置§4A§c]に設置してください");
						}
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§9ハンター開放停止装置§4A§c]が未設置です");
					}
					return;
				}
				case SURRENDER_BLOCK: {
					if(SURRENDER_BLOCK == null) {
						SURRENDER_BLOCK = block;
						player.sendMessage(TosoCommands.pex+"§e[§7自首装置§4A§e]を設置しました");
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§7自首装置§4A§c]は既に設置されています");
					}
					return;
				}
				case SURRENDER_BUTTON: {
					if(SURRENDER_BLOCK != null) {
						if(onLocation(SURRENDER_BLOCK, event.getBlockAgainst().getLocation())) {
							if(SURRENDER_BUTTON == null) {
								SURRENDER_BUTTON = block;
								player.sendMessage(TosoCommands.pex+"§e[§7自首装置§1B§e]を設置しました");
							} else {
								event.setCancelled(true);
								player.sendMessage(TosoCommands.pex+"§c[§7自首装置§1B§c]は既に設置されています");
							}
						} else {
							event.setCancelled(true);
							player.sendMessage(TosoCommands.pex+"§c[§7自首装置§4A§c]に設置してください");
						}
					} else {
						event.setCancelled(true);
						player.sendMessage(TosoCommands.pex+"§c[§7自首装置§4A§c]が未設置です");
					}
					return;
				}
				default: return;
				}
			}
		}
	}
	@EventHandler
	public void onBlockBreak(BlockBreakEvent event) {
		if(HIYU_TosoGame.read){
			Player player = event.getPlayer();
			if(TosoGameAPI.isAdmin(player)) {
				Block block = event.getBlock();
				Location search = block.getLocation();
				if(onLocation(SUCCESS_BLOCK, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§a逃走成功装置§4A§e]を§c破壊§eしました");
					SUCCESS_BLOCK = null;
					return;
				}
				if(onLocation(SUCCESS_BUTTON, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§a逃走成功装置§1B§e]を§c破壊§eしました");
					SUCCESS_BUTTON = null;
					return;
				}
				if(onLocation(AREA_CHEST, search)) {
					event.setCancelled(true);
					deleteBlock(block, true);
					player.sendMessage(TosoCommands.pex+"§e[§6拡張装置保管庫§e]を§c破壊§eしました");
					AREA_CHEST = null;
					return;
				}
				if(onLocation(BLOCKING_BLOCK, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§9ハンター開放停止装置§4A§e]を§c破壊§eしました");
					BLOCKING_BLOCK = null;
					return;
				}
				if(onLocation(BLOCKING_BUTTON, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§9ハンター開放停止装置§1B§e]を§c破壊§eしました");
					BLOCKING_BUTTON = null;
					return;
				}
				if(onLocation(SURRENDER_BLOCK, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§7自首装置§4A§e]を§c破壊§eしました");
					SURRENDER_BLOCK = null;
					return;
				}
				if(onLocation(SURRENDER_BUTTON, search)) {
					player.sendMessage(TosoCommands.pex+"§e[§7自首装置§1B§e]を§c破壊§eしました");
					SURRENDER_BUTTON = null;
					return;
				}
				return;
			}
		}
	}
	@EventHandler
	public void onPlayerInteract(PlayerInteractEvent event) {
		if(HIYU_TosoGame.read) {
			Player player = event.getPlayer();
			if(event.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
				Block block = event.getClickedBlock();
				if(block.getType().equals(Material.STONE_BUTTON) && TosoGameAPI.isTosoPlayer(player) && !TosoGameAPI.isCaughtPlayer(player)) {
					if(SUCCESS_BUTTON != null && onLocation(SUCCESS_BUTTON, block.getLocation())) {
						event.setCancelled(true);
						TosoGameAPI.addSuccessPlayer(player);
						Utility.sendAnnounce("MissionAnnounce.SuccessMission", player);
						Location sl = TosoGameAPI.getSuccessLocation();
						if(sl != null) player.teleport(sl);
						return;
					}
					if(BLOCKING_BUTTON != null && onLocation(BLOCKING_BUTTON, block.getLocation())) {
						if(!BLOCKING_FLAG) {
							if(BLOCKING_TIME > 0) {
								//ミッション成功
								BLOCKING_FLAG = true;
								BLOCKING_TIME = -1;
								Utility.sendAnnounce("MissionAnnounce.BlockingMission.Successful", player);
							} else {
								//ミッション失敗後にスイッチを押す
								BLOCKING_FLAG = true;
							}
						}
						return;
					}
					if(SURRENDER_BUTTON != null && onLocation(SURRENDER_BUTTON, block.getLocation())) {
						if(!startSurrener(player)) {
							event.setCancelled(true);
						}
						return;
					}
				}
			}
		}
	}
	// (AREA_CHEST != null)時のみ、つまりミッション用チェストを設置しないと動作しない
	@EventHandler
	public void onAreaMission(PlayerMoveEvent event){
		if(HIYU_TosoGame.read && AREA_CHEST != null){
			Player player = event.getPlayer();
			if(TosoGameAPI.isTosoPlayer(player) && !TosoGameAPI.isCaughtPlayer(player)) {
				ItemStack hand = player.getItemInHand();
				if(hand.getType().equals(Material.AIR)) return;
				for(MItem item : TCMission.area_content) {
					if(item != null && item.equals(hand)) {
						Location loc = player.getLocation();
						if(loc.clone().subtract(0d, 1d, 0d).getBlock().getType().equals(Material.DIAMOND_BLOCK) && loc.getBlock().getType().equals(Material.IRON_DOOR_BLOCK)) {
							Utility.sendAnnounce("MissionAnnounce.AreaMission", player);
							loc.getBlock().setType(Material.AIR);
							return;
						}
					}
				}
			}
		}
	}
	public static void reset() {
		HIYU_TosoGame.plugin.getLogger().info("Delete Mission Blocks");
		deleteBlock(SUCCESS_BUTTON, false);
		SUCCESS_BUTTON = null;
		deleteBlock(SUCCESS_BLOCK, false);
		SUCCESS_BLOCK = null;
		deleteBlock(AREA_CHEST, false);
		AREA_CHEST = null;
		deleteBlock(BLOCKING_BUTTON, false);
		BLOCKING_BUTTON = null;
		deleteBlock(BLOCKING_BLOCK, false);
		BLOCKING_BLOCK = null;
		deleteBlock(SURRENDER_BUTTON, false);
		SURRENDER_BUTTON = null;
		deleteBlock(SURRENDER_BLOCK, false);
		SURRENDER_BLOCK = null;
		SURRENDER_PLAYERS = new HashMap<String, UUID>();
		BLOCKING_FLAG = false;
		BLOCKING_TIME = -1;
		removeZombieHunter();
	}
	public static void removeZombieHunter() {
		for(World w : Bukkit.getWorlds()) {
			for(Entity ent : w.getEntities()) {
				if(isHunterZombie(ent)) ent.remove();
			}
		}
	}
	boolean onLocation(Block target, Location search) {
		if(target == null) return false;
		Location loc = target.getLocation();
		if(loc.getWorld().getName().equals(search.getWorld().getName())) {
			return loc.getBlockX() == search.getBlockX() && loc.getBlockY() == search.getBlockY() && loc.getBlockZ() == search.getBlockZ();
		} else return false;
	}
	private static void deleteBlock(Block block, boolean arg) {
		if(arg) {
			if(block.getType().equals(Material.CHEST))
				((Chest)block.getState()).getBlockInventory().clear();
			block.setType(Material.AIR);
		} else {
			if(block != null) {
				Location l = block.getLocation();
				System.out.println("{type:"+block.getType().name()+",x:"+l.getBlockX()+",y:"+l.getBlockY()+",z:"+l.getBlockZ()+"}");
				Chunk chunk = block.getChunk();
				if(!chunk.isLoaded()) {
					block.getChunk().load();
					deleteBlock(block, true);
					block.getChunk().unload();
				} else {
					deleteBlock(block, true);
				}
			}
		}
	}

	public static boolean addBox(int id, Location location) {
		if(HIYU_TosoGame.read) {
			Config co = HIYU_TosoGame.mission;
			String path = "Missions.Blocking.Boxs.box"+id;
			if(location != null){
				StringBuilder sb = new StringBuilder();
				sb.append(location.getWorld().getName());
				sb.append(',');
				sb.append(location.getBlockX());
				sb.append(',');
				sb.append(location.getBlockY());
				sb.append(',');
				sb.append(location.getBlockZ());
				co.set(path, sb.toString());
			} else {
				co.set(path, null);
			}
			return co.save();
		} return false;
	}
	public static Location getBox(int id) {
		return getBox("box"+id);
	}
	private static Location getBox(String id) {
		try {
			String arg = HIYU_TosoGame.mission.getString("Missions.Blocking.Boxs."+id);
			try {
				String[] args = arg.split(",");
				World w = Bukkit.getWorld(args[0]);
				if(w == null) return null;
				int x = Integer.parseInt(args[1]);
				int y = Integer.parseInt(args[2]);
				int z = Integer.parseInt(args[3]);
				return new Location(w,x,y,z);
			} catch(IllegalArgumentException ex) {
				return null;
			}
		} catch (ConfigNotFoundException e) {
			return null;
		}
	}
	private static List<Location> getBoxs() {
		if(HIYU_TosoGame.read) {
			List<Location> boxs = new ArrayList<Location>();
			for(String arg : HIYU_TosoGame.mission.getKeys("Missions.Blocking.Boxs")) {
				Location box = getBox(arg);
				if(box != null) boxs.add(box);
			}
			return boxs;
		} return new ArrayList<Location>();
	}
	public static void openBoxs(){
		if(HIYU_TosoGame.read) {
			for(Location l : getBoxs()){
				Chunk c = l.getChunk();
				boolean load = c.isLoaded();
				if(!load) c.load();
				l.getBlock().setType(Material.AIR);
				spawnZombie(l.clone().add(0.5d, 0d, 0.5d));
				l.getWorld().createExplosion(l.clone().add(0.5d, 0.5, 0.5), 0);
			}
		}
	}
	private static void spawnZombie(Location location) {
		Zombie zom = (Zombie)location.getWorld().spawnEntity(location, EntityType.ZOMBIE);
		EntityEquipment eu = zom.getEquipment();
		eu.setArmorContents(new ItemStack[]{
				new ItemStack(Material.DIAMOND_BOOTS),
				new ItemStack(Material.DIAMOND_LEGGINGS),
				new ItemStack(Material.DIAMOND_CHESTPLATE),
				new ItemStack(Material.DIAMOND_HELMET)
		});
		zom.setBaby(false);
		zom.setVillager(false);
		int level = 1;
		try {
			level = HIYU_TosoGame.mission.getInt("Missions.Blocking.ZombieSpeed");
		} catch(ConfigNotFoundException e){}
		zom.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, level, true));
		zom.setMetadata("HunterZombie", new FixedMetadataValue(HIYU_TosoGame.plugin, true));
		new SearchTask(zom).runTaskTimer(HIYU_TosoGame.plugin, 10l, 10l);
	}
	private static class SearchTask extends BukkitRunnable {
		Zombie zom;
		Location loc = null;
		private SearchTask(Zombie zom) {
			this.zom = zom;
			this.loc = zom.getLocation();
		}
		@Override
		public void run() {
			if(TosoTimer.onGame) {
				if(zom != null && !zom.isDead()) {
					loc = zom.getLocation();
				} else {
					spawnZombie(loc);
					cancel();
				}
			} else {
				cancel();
			}
		}
	}
	public static boolean isHunterZombie(Entity zom) {
		return zom.hasMetadata("HunterZombie");
	}
	public static boolean startBlockingTimer(int time) {
		if(BLOCKING_TIME == -1) {
			BLOCKING_TIME = time;
			Utility.sendAnnounce("MissionAnnounce.BlockingMission.Start", null, null, BLOCKING_TIME);
			return true;
		}
		return false;
	}
	public static void announceBlocking(int late) {
		if(late <= 10 || late == 30 || late == 60 || late == 180 || late == 300){
			Utility.sendAnnounce("MissionAnnounce.BlockingMission.Timer", null, null, late);
		}
	}
	public static void failedBlocking(int late) {
		Utility.sendAnnounce("MissionAnnounce.BlockingMission.Failed", null);
		openBoxs();
		BLOCKING_TIME = -1;
	}

	private Pattern pa = Pattern.compile("\\{(yes:|no:)?([^,]*)\\}");
	private boolean startSurrener(final Player player) {
		final String name = player.getName();
		if(!SURRENDER_PLAYERS.containsKey(name)) {
			final UUID uuid = UUID.randomUUID();
			SURRENDER_PLAYERS.put(name, uuid);
			Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Calling", player);
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
				@Override
				public void run() {
					if(!TosoGameAPI.isCaughtPlayer(player)) {
						Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Leading", player);
						Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
							@Override
							public void run() {
								if(!TosoGameAPI.isCaughtPlayer(player)) {
									Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Question", player);
									sendSurrenerTellraw(player, uuid);
								} else {
									Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Failed", player);
								}
							}
						}, 60l);
					} else {
						Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Failed", player);
					}
				}
			}, 200l);
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
				@Override
				public void run() {
					if(SURRENDER_PLAYERS.containsKey(name)) {
						SURRENDER_PLAYERS.remove(name);
						if(!TosoGameAPI.isCaughtPlayer(player))
							Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Failed", player);
					}
				}
			}, 660l);
			return true;
		} else return false;
	}
	private void sendSurrenerTellraw(Player player, UUID uuid) {
		String format = HIYU_TosoGame.mission.optString("Missions.Surrender.Tellraw", "{§7[ },{yes:§a自首},{§7 | },{no:§cキャンセル},{§7 ]}");
		StringBuilder sb = new StringBuilder();
		//sb.append("");
		Matcher ma = pa.matcher(format);
		while(ma.find()) {
			String text = ma.group(2) == null ? "" : ma.group(2);
			sb.append(",{text:\"");
			sb.append(text);
			if(ma.group(1) != null) {
				sb.append("\",clickEvent:{action:run_command,value:\"");
				if(ma.group(1).startsWith("yes")) {
					sb.append("＿surrender ");
					sb.append(uuid.toString());
				} else {
					sb.append("＿surrender");
				}
				sb.append("\"}}");
			} else {
				sb.append("\"}");
			}
		}
		String a = sb.toString();
		if(a.length() > 0) a = a.substring(1);
		Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tellraw "+player.getName()+"  {text:\"\",extra:["+a+"]}");
	}
	@EventHandler(priority=EventPriority.MONITOR)
	public void onPlayerSurrender(AsyncPlayerChatEvent event){
		final Player player = event.getPlayer();
		final String msg = event.getMessage();
		if(msg.startsWith("＿surrender")) {
			event.setCancelled(true);
			Bukkit.getScheduler().runTaskLater(HIYU_TosoGame.plugin, new Runnable() {
				@Override
				public void run() {
					onSurrender(player, msg);
				}
			}, 0l);
		}
	}
	private void onSurrender(Player player, String msg) {
		String name = player.getName();
		String[] args = msg.split(" ");
		if(TosoGameAPI.isTosoPlayer(player) && !TosoGameAPI.isCaughtPlayer(player)) {
			if(args.length == 2) {
				try {
					UUID uuid = UUID.fromString(args[1]);
					if(SURRENDER_PLAYERS.containsKey(name)) {
						if(SURRENDER_PLAYERS.get(name).equals(uuid)) {
							Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Successful", player);
							if(SURRENDER_PLAYERS.containsKey(name)) SURRENDER_PLAYERS.remove(name);

							TosoGameAPI.addCaughtPlayer(player);
							Location l = TosoGameAPI.getJailLocation();
							if(l != null) player.teleport(l);
							return;
						}
					}
					Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Error", player);
				} catch(IllegalArgumentException ex) {}
			} else if(args.length == 1) {
				if(SURRENDER_PLAYERS.containsKey(name)) {
					SURRENDER_PLAYERS.remove(name);
					Utility.sendAnnounce("MissionAnnounce.SurrenderMission.Cancelled", player);
				}
				return;
			}
		}
	}
}