/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.utile.PlaySoundAPI;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TCBook {

	static String pex = TosoCommands.pex;
	public static void doCommand(CommandSender sender, String label, String[] args){
		if(args.length == 1) {
			senderror(sender, label);
			return;
		}
		if(args[1].equalsIgnoreCase("send")) {
			if(args.length >= 3) {
				if(sendMission("Books."+args[2])) {
					return;
				} else {
					sender.sendMessage(pex+"§c指定されたミッションが見つかりません("+args[2]+")");
					return;
				}
			} else {
				sender.sendMessage("§c/"+label+" book send <Title>");
				return;
			}
		}
		senderror(sender, label);
		return;
	}
	private static void senderror(CommandSender sender, String label) {
		sender.sendMessage("/"+label+" book send <Title>");
	}
	@SuppressWarnings("deprecation")
	public static ItemStack giveBook(Player player) {
		ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
		BookMeta meta = (BookMeta) book.getItemMeta();
		meta.setTitle("逃走中");
		meta.setAuthor("Run For Money");
		book.setItemMeta(meta);
		player.getInventory().addItem(book);
		player.updateInventory();
		return getBook(player, false);
	}
	private static ItemStack getBook(Player player, boolean send){
		for(ItemStack item : player.getInventory().getContents()){
			if(item != null && item.getType().equals(Material.WRITTEN_BOOK)){
				return item;
			}
		}
		if(send) return giveBook(player);
		else return null;
	}
	public static boolean sendMission(String path) {
		if(HIYU_TosoGame.read){
			Config config = HIYU_TosoGame.book;
			if(config.contains(path)) {
				String text = null;
				String msg = null;
				String name = "none";
				float vol = 1f;
				float pit = 1f;
				try {
					List<String> texts = config.getStringList(path+".Text");
					text = texts.size() > 0 ? texts.get(0) : "";
					for(int i = 1; i < texts.size(); i++) {
						text += "\n"+texts.get(i);
					}
				}catch(ConfigNotFoundException e){}
				//Message
				try {
					msg = config.getString(path+".Message");
				}catch(ConfigNotFoundException e){}
				//Sound
				try {
					String arg = config.getString(path+".Sound");
					String[] args = arg.split(" ");
					try{
						name = args[0];
						vol = Float.parseFloat(args[1]);
						pit = Float.parseFloat(args[2]);
					}catch(ArrayIndexOutOfBoundsException | NumberFormatException e){}
				}catch(ConfigNotFoundException e){}
				for(Player player : Utility.getOnlinePlayers()) {
					if(!TosoGameAPI.isHunterPlayer(player)) {
						if(text != null) {
							ItemStack item = getBook(player, true);
							if(item != null) {
								BookMeta meta = (BookMeta)item.getItemMeta();
								meta.addPage(text);
								item.setItemMeta(meta);
							} else {
								continue;
							}
						}
						if(msg != null) {
							player.sendMessage(msg);
						}
						if(!name.equalsIgnoreCase("none")) {
							PlaySoundAPI.playSound(player, name, player.getLocation(), vol, pit);
						}
					}
				}
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	public static String[] getMissions() {
		List<String> list = new ArrayList<String>();
		if(HIYU_TosoGame.read){
			Config config = HIYU_TosoGame.book;
			for(String s : config.getKeys("Books.")) {
				list.add(s);
			}
		}
		return list.toArray(new String[0]);
	}
}
