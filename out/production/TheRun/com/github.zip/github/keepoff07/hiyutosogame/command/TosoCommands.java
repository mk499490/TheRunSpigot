/*
 * @author keepoff07
 * @license LGPLv3
 * @copyright Copyright keepoff07 2015
 */
package com.github.keepoff07.hiyutosogame.command;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import com.github.keepoff07.hiyutosogame.HIYU_TosoGame;
import com.github.keepoff07.hiyutosogame.TosoGameAPI;
import com.github.keepoff07.hiyutosogame.listener.TLMission;
import com.github.keepoff07.hiyutosogame.listener.TLPlayerControl;
import com.github.keepoff07.hiyutosogame.timer.TosoTimer;
import com.github.keepoff07.hiyutosogame.utile.PlaySoundAPI;
import com.github.keepoff07.hiyutosogame.utile.TosoScoreBoard;
import com.github.keepoff07.hiyutosogame.utile.Utility;
import com.github.keepoff07.hiyutosogame.utile.Utility.Config;
import com.github.keepoff07.hiyutosogame.utile.Utility.ConfigNotFoundException;

public class TosoCommands implements TabExecutor{

	public static String pex = "§8[§4逃走中§8] ";
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(!HIYU_TosoGame.read){
			sender.sendMessage("§c全てのファイルを正しく読み込めていません。");
			return true;
		}
		if(TCHelp.doCommand(sender, label, args)) {
			return true;
		}
		if(args[0].equalsIgnoreCase("start")){
			cmdStart(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("stop")){
			cmdStop(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("reset")){
			cmdReset(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("ending")){
			cmdED(sender);
			return true;
		}
		else if(args[0].equalsIgnoreCase("t")){
			TCPlayer.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("h")){
			TCHunter.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("timer")){
			TCTimer.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("p")){
			TCPoint.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("tp")){
			TCPoint.doCommand_tp(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("box")){
			TCBox.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("book")){
			TCBook.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("config")){
			TCConfig.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("reload")){
			TCConfig.AllReload(sender);
			return true;
		}
		else if(args[0].equalsIgnoreCase("gamemode")){
			TCGameMode.doCommand(sender, label, args);
			return true;
		}
		else if(args[0].equalsIgnoreCase("mission")){
			TCMission.doCommand(sender, label, args);
			return true;
		}
		else {
			return false;
		}
	}
	private void cmdReset(CommandSender sender, String label, String[] args){
		GameReset();
		sender.sendMessage(pex+"§aリセットしました。");
	}
	public static void GameReset() {
		Location l = TosoGameAPI.getJailLocation();
		TosoScoreBoard.reset();
		TosoTimer.endTimer();
		for(Player p : Utility.getOnlinePlayers()){
			if(!TosoGameAPI.isAdmin(p)){
				p.getInventory().clear();
				if(l != null) p.teleport(l);
			}
			TosoGameAPI.removeArmor(p);
			p.setWalkSpeed(0.2f);
			p.setFoodLevel(20);
			TLPlayerControl.loginSendItems(p);
			TosoScoreBoard.addTosoPlayer(p);
		}
		TosoTimer.setSideBar();
		TLMission.reset();
	}
	private void cmdStart(CommandSender sender, String label, String[] args){
		if(!TosoTimer.startTimer()){
			if(TosoTimer.onGame2) {
				sender.sendMessage(pex+"§7既にゲームが開始されています。");
			} else {
				TosoTimer.onGame = true;
				TosoTimer.onGame2 = true;
				Utility.sendAnnounce("TimeAnnounce.TimerUnsuspended", null);
			}
		}
	}
	private void cmdStop(CommandSender sender, String label, String[] args){
		if(TosoTimer.onGame2) {
			TosoTimer.onGame = false;
			TosoTimer.onGame2 = false;
			Utility.sendAnnounce("TimeAnnounce.TimerStop", null);
		} else {
			sender.sendMessage(pex+"§7既にゲームが停止されています。");
		}
	}
	private void cmdED(CommandSender sender){
		if(HIYU_TosoGame.read){
			Config config = HIYU_TosoGame.config;
			try {
				String wn = config.getString("Ending.WorldName");
				final World w = Bukkit.getServer().getWorld(wn);
				if(w == null) return;
				String arg = config.getString("Ending.Sound");
				String name = "none";
				float vol = 1f;
				float pit = 1f;
				String[] args = arg.split(" ");
				try{
					name = args[0];
					vol = Float.parseFloat(args[1]);
					pit = Float.parseFloat(args[2]);
				}catch(ArrayIndexOutOfBoundsException | NumberFormatException e){}
				Location[] l = {
						new Location(w, 0.5,2,0.5),
						new Location(w, 0,1,0),
						new Location(w, 0,0,0)};
				l[1].getBlock().setType(Material.ENDER_PORTAL);
				l[2].getBlock().setType(Material.BEDROCK);
				Vector v = new Vector(0,0,0);
				for(Player o : Utility.getOnlinePlayers()) {
					o.setVelocity(v);
					o.teleport(l[0]);
					if(!name.equalsIgnoreCase("none")) {
						PlaySoundAPI.playSound(o, name, l[0], vol, pit);
					}
				}
			}catch(ConfigNotFoundException ex){}
		}
	}
	@Override
	public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
		if(args.length > 3) return null;
		if(args.length > 2){
			if(args[0].equalsIgnoreCase("p")){
				return getTabAssist(args[2], "jail", "rev", "suc", "gath", "blocking");
			} else if(args[0].equalsIgnoreCase("book")){
				if(args[1].equalsIgnoreCase("send")){
					return getTabAssist(args[2], TCBook.getMissions());
				} else return null;
			} else if(args[0].equalsIgnoreCase("mission")){
				if(args[1].equalsIgnoreCase("zombie")){
					return getTabAssist(args[2], "add", "remove");
				} else return null;
			} else return null;
		}
		if(args.length > 1){
			if(args[0].equalsIgnoreCase("t")){
				return getTabAssist(args[1], "add", "remove", "clear");
			} else if(args[0].equalsIgnoreCase("h")){
				return getTabAssist(args[1], "add", "remove", "clear");
			} else if(args[0].equalsIgnoreCase("timer")){
				return getTabAssist(args[1], "set", "countdown", "end");
			} else if(args[0].equalsIgnoreCase("p")){
				return getTabAssist(args[1], "set");
			} else if(args[0].equalsIgnoreCase("box")){
				return getTabAssist(args[1], "add", "remove");
			} else if(args[0].equalsIgnoreCase("book")){
				return getTabAssist(args[1], "send");
			} else if(args[0].equalsIgnoreCase("config")){
				return getTabAssist(args[1], "edit");
			} else if(args[0].equalsIgnoreCase("tp")){
				return getTabAssist(args[1], "jail", "rev", "suc", "gath");
			} else if(args[0].equalsIgnoreCase("mission")){
				return getTabAssist(args[1], "success", "area", "blocking", "zombie", "surrender");
			} else return null;
		}
		if(args.length > 0){
			return getTabAssist(args[0], "start", "stop", "reset", "t", "h", "timer", "p", "box", "book", "config", "reload", "gamemode", "ending", "mission");
		}
		return null;
	}
	public List<String> getTabAssist(String arg, String... args){
		List<String> list = new ArrayList<String>();
		for(String s : args){
			if(s.toLowerCase().startsWith(arg.toLowerCase())) list.add(s);
		}
		return list;
	}
}
