package com.tosogame.miyanopeko.tosoplayer;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;

import com.tosogame.miyanopeko.main.Tosogame2;

public class TosoPlayer {

    /**
     * 任意のプレイヤーを確保状態にすることができます。
     * そのプレイヤーは即時に牢獄に飛ばされます。<br>
     * <b>※tosogame.playerの権限がないか、既に確保されている場合、
     * そしてサーバにログインしていない場合は機能しません。</b>
     * @param player （確保されていない）逃走者
     */
    public void kakuho(Player player){
        if(player.hasPermission("tosogame.player")){
            if(Tosogame2.plugin.kakuho.contains(player.getName())==false){
                TosoPlayer tp = new TosoPlayer();
                tp.setTeam(player, "jail");
                final Tosogame2 PL = Tosogame2.plugin;
                String name = PL.getConfig().getString("Jail.main");
                Location loc = new Location(PL.getServer().getWorld(PL.getConfig().getString("Jail.list."+name+".world")),
                        PL.getConfig().getDouble("Jail.list." + name + ".x"),
                        PL.getConfig().getDouble("Jail.list." + name + ".y"),
                        PL.getConfig().getDouble("Jail.list." + name + ".z")
                );
                Tosogame2.plugin.kakuho.add(player.getName());
                setColor(player, ChatColor.BLACK);
                player.teleport(loc);
            }
        }
    }

    /**
     *任意のプレイヤーを復活させることができます。
     *そのプレイヤーは即時に復活地点に飛ばされます。<br>
     * <b>※tosogame.playerの権限がないか、確保されていない場合、
     * そしてサーバにログインしていない場合は機能しません。</b>
     * @param player 復活させたい（確保状態の）逃走者
     */
    public void release(Player player){
        if(player.hasPermission("tosogame.player") & Tosogame2.plugin.kakuho.contains(player.getName())){
            TosoPlayer tp = new TosoPlayer();
            tp.setTeam(player, "toso");
            final Tosogame2 PL = Tosogame2.plugin;
            String name = PL.getConfig().getString("Release.main");
            Location loc = new Location(PL.getServer().getWorld(PL.getConfig().getString("Release.list."+name+".world")),
                    PL.getConfig().getDouble("Release.list." + name + ".x"),
                    PL.getConfig().getDouble("Release.list." + name + ".y"),
                    PL.getConfig().getDouble("Release.list." + name + ".z")
            );
            Tosogame2.plugin.kakuho.remove(player.getName());
            setColor(player, ChatColor.WHITE);
            player.teleport(loc);
        }
    }

    /**
     * 任意のパーミッションを持つプレイヤー全員に、アイテムを配布することができます。<br>
     * 逃走者にアイテムを配布する場合などで、確保/未確保関係なくアイテムが送られるので注意してください。
     * @param permission アイテム配布を行う権限
     * @param item 配布するアイテム（ItemStack）
     */
    public void giveItem(String permission, ItemStack... item){
        for(Player player : Bukkit.getServer().getOnlinePlayers()){
            if(player.hasPermission(permission)){
                player.getInventory().addItem(item);
            }
        }
    }

    /**
     * 逃走者にミッション告知用の本を配布します。<br>
     * 既に「逃走中」というタイトルの本を持っている場合はスルーされます。
     */
    public void giveBook(){
        for(Player player : Bukkit.getServer().getOnlinePlayers()){
            if(player.hasPermission("tosogame.player")||player.hasPermission("tosogame.admin")){
                if(player.getInventory().contains(Material.WRITTEN_BOOK)){
                    if(hasBook(player))sendbook(player);
                }else{
                    sendbook(player);
                }
            }
        }
    }

    /**
     * 指定したプレイヤーが「逃走中」というタイトルの本を持っているかどうか調べることができます。
     * @param player 調べたいプレイヤー
     * @return true 本を持っている / false 本を持っていない
     */
    public boolean hasBook(Player player){
        for(ItemStack item : player.getInventory().getContents()){
            if(item != null){
                if(item.getType().equals(Material.WRITTEN_BOOK)){
                    BookMeta meta = (BookMeta) item.getItemMeta();
                    if(meta.getTitle().equals("逃走中")){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    /**
     *
     * @param player
     * @param teamname
     * @deprecated
     */
    public void setTeam(Player player, String teamname){
        Tosogame2 toso = Tosogame2.plugin;
        if(player.getScoreboard().equals(toso.tososcore)){
            toso.tososcore.getTeam(teamname).addPlayer(player);
        }
    }

    private void sendbook(Player player){
        ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        BookMeta meta = (BookMeta) book.getItemMeta();
        meta.setTitle("逃走中");
        book.setItemMeta(meta);
        player.getInventory().addItem(book);
    }

    /**
     * プレイヤーリストのカラーを変更します
     * @param player プレイヤー
     * @param color ChatColor
     */
    public void setColor(Player player, ChatColor color){
        String name = (color + player.getName());
        if(name.length() > 16){
            name = name.substring(0, 15);
        }
        player.setPlayerListName(name);
    }
}